import { FormDataEntryApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[POST] Form data entry endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new FormDataEntryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formDataEntryPost(
        {
          id: 0,
          projectId: "00000000-0000-0000-0000-000000000000",
          entityId: "00000000-0000-0000-0000-000000000000",
          subjectId: 0,
          status: 0,
          createdBy: "00000000-0000-0000-0000-000000000000",
          createdDate: new Date("2019-08-08T01:18:05.812Z"),
          modifiedBy: 0,
          modifiedDate: new Date("2019-08-08T01:18:05.812Z"),
          deactivatedBy: 0,
          dateDeactivated: new Date("2019-08-08T01:18:05.812Z"),
          guid: "00000000-0000-0000-0000-000000000000",
          activityId: "00000000-0000-0000-0000-000000000000",
          tenantId: "00000000-0000-0000-0000-000000000000",
          activity: {
            activityName: "string",
            dependentActivityId: "00000000-0000-0000-0000-000000000000",
            activityCategoryId: "00000000-0000-0000-0000-000000000000",
            startDate: new Date("2019-08-08T01:18:05.812Z"),
            endDate: new Date("2019-08-08T01:18:05.812Z"),
            scheduleType: 0,
            activityStatusId: "00000000-0000-0000-0000-000000000000",
            activityStatusName: "string",
            createdBy: "00000000-0000-0000-0000-000000000000",
            createdDate: new Date("2019-08-08T01:18:05.812Z"),
            modifiedBy: "00000000-0000-0000-0000-000000000000",
            modifiedDate: new Date("2019-08-08T01:18:05.812Z"),
            deactivatedBy: "00000000-0000-0000-0000-000000000000",
            dateDeactivated: new Date("2019-08-08T01:18:05.812Z"),
            guid: "00000000-0000-0000-0000-000000000000",
            projectId: "00000000-0000-0000-0000-000000000000",
            tenantId: "00000000-0000-0000-0000-000000000000",
            forms: [
              {
                id: "00000000-0000-0000-0000-000000000000",
                formTitle: "string",
                status: "string",
                roles: ["00000000-0000-0000-0000-000000000000"]
              }
            ],
            entityTypes: ["00000000-0000-0000-0000-000000000000"],
            activityRoles: ["00000000-0000-0000-0000-000000000000"],
            activityRoleNames: ["string"],
            isDefaultActivity: 0,
            isActivityRequireAnEntity: true,
            repeatationCount: 0,
            repeatationOffset: 0
          },
          formDataEntryVariable: [
            {
              id: 0,
              variableId: 0,
              selectedValues: "string",
              selectedValuesInt: 0,
              selectedValuesFloat: 0,
              formDataEntryId: 0,
              createdBy: 0,
              createdDate: new Date("2019-08-08T01:18:05.812Z"),
              modifiedBy: 0,
              modifiedDate: new Date("2019-08-08T01:18:05.812Z"),
              deactivatedBy: 0,
              dateDeactivated: new Date("2019-08-08T01:18:05.812Z"),
              guid: "00000000-0000-0000-0000-000000000000",
              variableName: "string",
              formId: 0,
              parentId: 0,
              activityId: 0,
              formGuid: "00000000-0000-0000-0000-000000000000",
              activityGuid: "00000000-0000-0000-0000-000000000000",
              formDataEntryStatus: 0,
              formTitle: "string"
            }
          ],
          formId: "00000000-0000-0000-0000-000000000000",
          participantId: "string",
          formTitle: "string",
          thisUserId: 0,
          parentEntityNumber: 0,
          projectDeployStatus: 0,
          projectDeployedId: "string",
          projectDeployedVersion: "string",
          summaryPageActivityObjId: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Form data entry endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new FormDataEntryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formDataEntryPost(
        {
          id: 0,
          projectId: "00000000-0000-0000-0000-000000000000",
          entityId: "00000000-0000-0000-0000-000000000000",
          subjectId: 0,
          status: 0,
          createdBy: "00000000-0000-0000-0000-000000000000",
          createdDate: new Date("2019-08-08T01:18:05.812Z"),
          modifiedBy: 0,
          modifiedDate: new Date("2019-08-08T01:18:05.812Z"),
          deactivatedBy: 0,
          dateDeactivated: new Date("2019-08-08T01:18:05.812Z"),
          guid: "00000000-0000-0000-0000-000000000000",
          activityId: "00000000-0000-0000-0000-000000000000",
          tenantId: "00000000-0000-0000-0000-000000000000",
          activity: {
            activityName: "string",
            dependentActivityId: "00000000-0000-0000-0000-000000000000",
            activityCategoryId: "00000000-0000-0000-0000-000000000000",
            startDate: new Date("2019-08-08T01:18:05.812Z"),
            endDate: new Date("2019-08-08T01:18:05.812Z"),
            scheduleType: 0,
            activityStatusId: "00000000-0000-0000-0000-000000000000",
            activityStatusName: "string",
            createdBy: "00000000-0000-0000-0000-000000000000",
            createdDate: new Date("2019-08-08T01:18:05.812Z"),
            modifiedBy: "00000000-0000-0000-0000-000000000000",
            modifiedDate: new Date("2019-08-08T01:18:05.812Z"),
            deactivatedBy: "00000000-0000-0000-0000-000000000000",
            dateDeactivated: new Date("2019-08-08T01:18:05.812Z"),
            guid: "00000000-0000-0000-0000-000000000000",
            projectId: "00000000-0000-0000-0000-000000000000",
            tenantId: "00000000-0000-0000-0000-000000000000",
            forms: [
              {
                id: "00000000-0000-0000-0000-000000000000",
                formTitle: "string",
                status: "string",
                roles: ["00000000-0000-0000-0000-000000000000"]
              }
            ],
            entityTypes: ["00000000-0000-0000-0000-000000000000"],
            activityRoles: ["00000000-0000-0000-0000-000000000000"],
            activityRoleNames: ["string"],
            isDefaultActivity: 0,
            isActivityRequireAnEntity: true,
            repeatationCount: 0,
            repeatationOffset: 0
          },
          formDataEntryVariable: [
            {
              id: 0,
              variableId: 0,
              selectedValues: "string",
              selectedValuesInt: 0,
              selectedValuesFloat: 0,
              formDataEntryId: 0,
              createdBy: 0,
              createdDate: new Date("2019-08-08T01:18:05.812Z"),
              modifiedBy: 0,
              modifiedDate: new Date("2019-08-08T01:18:05.812Z"),
              deactivatedBy: 0,
              dateDeactivated: new Date("2019-08-08T01:18:05.812Z"),
              guid: "00000000-0000-0000-0000-000000000000",
              variableName: "string",
              formId: 0,
              parentId: 0,
              activityId: 0,
              formGuid: "00000000-0000-0000-0000-000000000000",
              activityGuid: "00000000-0000-0000-0000-000000000000",
              formDataEntryStatus: 0,
              formTitle: "string"
            }
          ],
          formId: "00000000-0000-0000-0000-000000000000",
          participantId: "string",
          formTitle: "string",
          thisUserId: 0,
          parentEntityNumber: 0,
          projectDeployStatus: 0,
          projectDeployedId: "string",
          projectDeployedVersion: "string",
          summaryPageActivityObjId: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Form data entry endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new FormDataEntryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formDataEntryEdit(
        "00000000-0000-0000-0000-000000000000",
        {
          id: 0,
          projectId: "00000000-0000-0000-0000-000000000000",
          entityId: "00000000-0000-0000-0000-000000000000",
          subjectId: 0,
          status: 0,
          createdBy: "00000000-0000-0000-0000-000000000000",
          createdDate: new Date("2019-08-08T01:18:05.812Z"),
          modifiedBy: 0,
          modifiedDate: new Date("2019-08-08T01:18:05.812Z"),
          deactivatedBy: 0,
          dateDeactivated: new Date("2019-08-08T01:18:05.812Z"),
          guid: "00000000-0000-0000-0000-000000000000",
          activityId: "00000000-0000-0000-0000-000000000000",
          tenantId: "00000000-0000-0000-0000-000000000000",
          activity: {
            activityName: "string",
            dependentActivityId: "00000000-0000-0000-0000-000000000000",
            activityCategoryId: "00000000-0000-0000-0000-000000000000",
            startDate: new Date("2019-08-08T01:18:05.812Z"),
            endDate: new Date("2019-08-08T01:18:05.812Z"),
            scheduleType: 0,
            activityStatusId: "00000000-0000-0000-0000-000000000000",
            activityStatusName: "string",
            createdBy: "00000000-0000-0000-0000-000000000000",
            createdDate: new Date("2019-08-08T01:18:05.812Z"),
            modifiedBy: "00000000-0000-0000-0000-000000000000",
            modifiedDate: new Date("2019-08-08T01:18:05.812Z"),
            deactivatedBy: "00000000-0000-0000-0000-000000000000",
            dateDeactivated: new Date("2019-08-08T01:18:05.812Z"),
            guid: "00000000-0000-0000-0000-000000000000",
            projectId: "00000000-0000-0000-0000-000000000000",
            tenantId: "00000000-0000-0000-0000-000000000000",
            forms: [
              {
                id: "00000000-0000-0000-0000-000000000000",
                formTitle: "string",
                status: "string",
                roles: ["00000000-0000-0000-0000-000000000000"]
              }
            ],
            entityTypes: ["00000000-0000-0000-0000-000000000000"],
            activityRoles: ["00000000-0000-0000-0000-000000000000"],
            activityRoleNames: ["string"],
            isDefaultActivity: 0,
            isActivityRequireAnEntity: true,
            repeatationCount: 0,
            repeatationOffset: 0
          },
          formDataEntryVariable: [
            {
              id: 0,
              variableId: 0,
              selectedValues: "string",
              selectedValuesInt: 0,
              selectedValuesFloat: 0,
              formDataEntryId: 0,
              createdBy: 0,
              createdDate: new Date("2019-08-08T01:18:05.812Z"),
              modifiedBy: 0,
              modifiedDate: new Date("2019-08-08T01:18:05.812Z"),
              deactivatedBy: 0,
              dateDeactivated: new Date("2019-08-08T01:18:05.812Z"),
              guid: "00000000-0000-0000-0000-000000000000",
              variableName: "string",
              formId: 0,
              parentId: 0,
              activityId: 0,
              formGuid: "00000000-0000-0000-0000-000000000000",
              activityGuid: "00000000-0000-0000-0000-000000000000",
              formDataEntryStatus: 0,
              formTitle: "string"
            }
          ],
          formId: "00000000-0000-0000-0000-000000000000",
          participantId: "string",
          formTitle: "string",
          thisUserId: 0,
          parentEntityNumber: 0,
          projectDeployStatus: 0,
          projectDeployedId: "string",
          projectDeployedVersion: "string",
          summaryPageActivityObjId: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Form data entry endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new FormDataEntryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formDataEntryEdit(
        "00000000-0000-0000-0000-000000000000",
        {
          id: 0,
          projectId: "00000000-0000-0000-0000-000000000000",
          entityId: "00000000-0000-0000-0000-000000000000",
          subjectId: 0,
          status: 0,
          createdBy: "00000000-0000-0000-0000-000000000000",
          createdDate: new Date("2019-08-08T01:18:05.812Z"),
          modifiedBy: 0,
          modifiedDate: new Date("2019-08-08T01:18:05.812Z"),
          deactivatedBy: 0,
          dateDeactivated: new Date("2019-08-08T01:18:05.812Z"),
          guid: "00000000-0000-0000-0000-000000000000",
          activityId: "00000000-0000-0000-0000-000000000000",
          tenantId: "00000000-0000-0000-0000-000000000000",
          activity: {
            activityName: "string",
            dependentActivityId: "00000000-0000-0000-0000-000000000000",
            activityCategoryId: "00000000-0000-0000-0000-000000000000",
            startDate: new Date("2019-08-08T01:18:05.812Z"),
            endDate: new Date("2019-08-08T01:18:05.812Z"),
            scheduleType: 0,
            activityStatusId: "00000000-0000-0000-0000-000000000000",
            activityStatusName: "string",
            createdBy: "00000000-0000-0000-0000-000000000000",
            createdDate: new Date("2019-08-08T01:18:05.812Z"),
            modifiedBy: "00000000-0000-0000-0000-000000000000",
            modifiedDate: new Date("2019-08-08T01:18:05.812Z"),
            deactivatedBy: "00000000-0000-0000-0000-000000000000",
            dateDeactivated: new Date("2019-08-08T01:18:05.812Z"),
            guid: "00000000-0000-0000-0000-000000000000",
            projectId: "00000000-0000-0000-0000-000000000000",
            tenantId: "00000000-0000-0000-0000-000000000000",
            forms: [
              {
                id: "00000000-0000-0000-0000-000000000000",
                formTitle: "string",
                status: "string",
                roles: ["00000000-0000-0000-0000-000000000000"]
              }
            ],
            entityTypes: ["00000000-0000-0000-0000-000000000000"],
            activityRoles: ["00000000-0000-0000-0000-000000000000"],
            activityRoleNames: ["string"],
            isDefaultActivity: 0,
            isActivityRequireAnEntity: true,
            repeatationCount: 0,
            repeatationOffset: 0
          },
          formDataEntryVariable: [
            {
              id: 0,
              variableId: 0,
              selectedValues: "string",
              selectedValuesInt: 0,
              selectedValuesFloat: 0,
              formDataEntryId: 0,
              createdBy: 0,
              createdDate: new Date("2019-08-08T01:18:05.812Z"),
              modifiedBy: 0,
              modifiedDate: new Date("2019-08-08T01:18:05.812Z"),
              deactivatedBy: 0,
              dateDeactivated: new Date("2019-08-08T01:18:05.812Z"),
              guid: "00000000-0000-0000-0000-000000000000",
              variableName: "string",
              formId: 0,
              parentId: 0,
              activityId: 0,
              formGuid: "00000000-0000-0000-0000-000000000000",
              activityGuid: "00000000-0000-0000-0000-000000000000",
              formDataEntryStatus: 0,
              formTitle: "string"
            }
          ],
          formId: "00000000-0000-0000-0000-000000000000",
          participantId: "string",
          formTitle: "string",
          thisUserId: 0,
          parentEntityNumber: 0,
          projectDeployStatus: 0,
          projectDeployedId: "string",
          projectDeployedVersion: "string",
          summaryPageActivityObjId: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Form data entry Search participant endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new FormDataEntryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formDataEntrySearchParticipant(
        {
          searchVariables: [
            {
              key: 0,
              value: "string"
            }
          ],
          projectId: "00000000-0000-0000-0000-000000000000",
          formId: "00000000-0000-0000-0000-000000000000",
          formTitle: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Form data entry Search participant endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new FormDataEntryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formDataEntrySearchParticipant(
        {
          searchVariables: [
            {
              key: 0,
              value: "string"
            }
          ],
          projectId: "00000000-0000-0000-0000-000000000000",
          formId: "00000000-0000-0000-0000-000000000000",
          formTitle: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Form data entry endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new FormDataEntryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formDataEntryGet("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Form data entry endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new FormDataEntryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formDataEntryGet(
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
