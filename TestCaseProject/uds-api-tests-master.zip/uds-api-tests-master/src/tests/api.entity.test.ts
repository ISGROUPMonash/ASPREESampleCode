import { EntityApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[GET] Entity/GetAllEntriesCreatedBySearch endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new EntityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .entityGetAllEntitiesCreatedBySearch("")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Entity/GetAllEntriesCreatedBySearch endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new EntityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .entityGetAllEntitiesCreatedBySearch("bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
