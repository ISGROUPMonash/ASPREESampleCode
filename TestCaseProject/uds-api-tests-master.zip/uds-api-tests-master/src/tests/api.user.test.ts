import { UserApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[GET] User profile by guid endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new UserApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .userGet("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] User profile by guid endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new UserApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .userGet("00000000-0000-0000-0000-000000000000", "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] User by temporary guid endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new UserApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .userGetUserByTempGuid("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] User by temporary guid endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new UserApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .userGetUserByTempGuid(
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] User by main id endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new UserApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api.userGetUserById(123, "").catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] User by main id endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new UserApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .userGetUserById(123, "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Project users endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new UserApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .userGetProjectAllUsers("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Project users endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new UserApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .userGetProjectAllUsers(
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] All users endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new UserApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api.userGetAll("").catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] All users endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new UserApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api.userGetAll("bad auth header").catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] User endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new UserApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .userPost(
        {
          firstName: "string",
          lastName: "string",
          email: "string",
          mobile: "string",
          address: "string",
          roleId: "00000000-0000-0000-0000-000000000000",
          tenantId: "00000000-0000-0000-0000-000000000000",
          profile: "string",
          userName: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] User endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new UserApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .userPost(
        {
          firstName: "string",
          lastName: "string",
          email: "string",
          mobile: "string",
          address: "string",
          roleId: "00000000-0000-0000-0000-000000000000",
          tenantId: "00000000-0000-0000-0000-000000000000",
          profile: "string",
          userName: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] User endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new UserApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .userDelete("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] User endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new UserApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .userDelete("00000000-0000-0000-0000-000000000000", "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] User by guid endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new UserApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .userGet("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] User by guid endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new UserApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .userGet("00000000-0000-0000-0000-000000000000", "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] User endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new UserApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .userPut(
        "00000000-0000-0000-0000-000000000000",
        {
          firstName: "string",
          lastName: "string",
          email: "string",
          mobile: "string",
          address: "string",
          roleId: "00000000-0000-0000-0000-000000000000",
          tenantId: "00000000-0000-0000-0000-000000000000",
          profile: "string",
          userName: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] User endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new UserApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .userPut(
        "00000000-0000-0000-0000-000000000000",
        {
          firstName: "string",
          lastName: "string",
          email: "string",
          mobile: "string",
          address: "string",
          roleId: "00000000-0000-0000-0000-000000000000",
          tenantId: "00000000-0000-0000-0000-000000000000",
          profile: "string",
          userName: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
