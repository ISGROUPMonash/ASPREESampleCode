import { VariableTypeApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[GET] All variable types endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new VariableTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api.variableTypeGetAll("").catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] All variable types endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new VariableTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variableTypeGetAll("bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Variable type endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new VariableTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variableTypePost(
        {
          type: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Variable type endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new VariableTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variableTypePost(
        {
          type: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] Variable type endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new VariableTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variableTypeDelete("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] Variable type endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new VariableTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variableTypeDelete(
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Variable type endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new VariableTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variableTypeGet("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Variable type endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new VariableTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variableTypeGet(
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Variable type endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new VariableTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variableTypePut(
        "00000000-0000-0000-0000-000000000000",
        {
          type: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Variable type endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new VariableTypeApi();
  expect.assertions(1);

  return repeatFlakeyTest(() =>
    api
      .variableTypePut(
        "00000000-0000-0000-0000-000000000000",
        {
          type: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
