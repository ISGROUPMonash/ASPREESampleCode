import { SecurityQuestionApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[GET] All security questions endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new SecurityQuestionApi();
  expect.assertions(0);
  return repeatFlakeyTest(() =>
    api.securityQuestionGetAll("").catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] All security questions endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new SecurityQuestionApi();
  expect.assertions(0);
  return repeatFlakeyTest(() =>
    api
      .securityQuestionGetAll("bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Security question endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new SecurityQuestionApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .securityQuestionPost(
        {
          question: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Security question endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new SecurityQuestionApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .securityQuestionPost(
        {
          question: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] Security question endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new SecurityQuestionApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .securityQuestionDelete("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] Security question endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new SecurityQuestionApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .securityQuestionDelete(
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Security question by guid endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new SecurityQuestionApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .securityQuestionGet("00000000-0000-0000-0000-000000000000")
      .catch(e => checkHTTPErrorCode(e, 404))//" Since authorization is no longer exists, thus for any wrong guid, it will through not found"
  );
});

test("[GET] Security question by guid endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new SecurityQuestionApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .securityQuestionGet(
        "00000000-0000-0000-0000-000000000000"
      )
      .catch(e => checkHTTPErrorCode(e, 404))//" Since authorization is no longer exists, thus for any wrong guid, it will through not found"
  );
});

test("[PUT] Security question guid endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new SecurityQuestionApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .securityQuestionPut(
        "00000000-0000-0000-0000-000000000000",
        {
          question: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Security question guid endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new SecurityQuestionApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .securityQuestionPut(
        "00000000-0000-0000-0000-000000000000",
        {
          question: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
