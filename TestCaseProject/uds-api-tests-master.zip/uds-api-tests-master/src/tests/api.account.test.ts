import { AccountApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[PUT] SecurityQuestion endpoint fails with invalid authentication if Authorization header is blank", async () => {
  const api = new AccountApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .accountSecurityQuestion(
        {
          guid: "00000000-0000-0000-0000-000000000000",
          userGuid: "00000000-0000-0000-0000-000000000000",
          answer: ""
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] SecurityQuestion endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new AccountApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .accountSecurityQuestion(
        {
          guid: "00000000-0000-0000-0000-000000000000",
          userGuid: "00000000-0000-0000-0000-000000000000",
          answer: ""
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] CheckUsernameAvailability/{userName}/{authType}/{userid} endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new AccountApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .accountCheckUsernameAvailability(
        "fakeuserser",
        "fakeauthtype",
        "fakeuserid",
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] CheckUsernameAvailability/{userName}/{authType}/{userid} endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new AccountApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .accountCheckUsernameAvailability(
        "fakeuserser",
        "fakeauthtype",
        "fakeuserid",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Change password endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new AccountApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .accountChangePassword(
        {
          oldPassword: "abc",
          password: "abcd",
          confirmPassword: "abcd"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Change password endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new AccountApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .accountChangePassword(
        {
          oldPassword: "abc",
          password: "abcd",
          confirmPassword: "abcd"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});


test("[PUT] Reset password endpoint should not require authentication", async () => {
  const api = new AccountApi();
  await api.accountResetForgetPassword(
    "00000000-0000-0000-0000-000000000000",
    {
      guid: "00000000-0000-0000-0000-000000000000",
      questionGuid: "00000000-0000-0000-0000-000000000000",
      answer: "test",
      password: "test1234",
      confirmPassword: "test1234"
    }
  );
});
