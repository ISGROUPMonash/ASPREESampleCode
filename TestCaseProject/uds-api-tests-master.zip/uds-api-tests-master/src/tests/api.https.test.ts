import * as UDSApi from "../api/api";
import url from "url";

/**
 * Checks whether the object is an API endpoint or not
 * @param obj the object to check
 */
function isApiEndpoint(obj: any): boolean {
  return typeof obj === "function" && obj.name.endsWith("Api");
}

// Check that all endpoints are served over HTTPS
Object.keys(UDSApi).forEach(apiEndpointName => {
  if (isApiEndpoint(UDSApi[apiEndpointName])) {
    const api = new UDSApi[apiEndpointName]();
    test(`${apiEndpointName} is served over HTTPS`, () => {
      const baseUrl = new url.URL(api.basePath);
      expect(baseUrl.protocol).toBe("https:");
    });
  }
});
