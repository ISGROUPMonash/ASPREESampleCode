import { ProjectApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[GET] Get all projects by user ID endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ProjectApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .projectGetAllProjectByUserId("")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Get all prjects by user ID endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ProjectApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .projectGetAllProjectByUserId("bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Project basic details endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ProjectApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .projectGetProjectBasicDetails("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Project basic details endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ProjectApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .projectGetProjectBasicDetails(
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Check entity linked project endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ProjectApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .projectCheckEntityLinkedProject("testprojectID", 123, "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Check entity linked project endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ProjectApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .projectCheckEntityLinkedProject("testprojectID", 123, "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Project endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ProjectApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .projectGet("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Project endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ProjectApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .projectGet("00000000-0000-0000-0000-000000000000", "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
