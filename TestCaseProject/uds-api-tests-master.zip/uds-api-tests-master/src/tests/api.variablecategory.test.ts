import { VariableCategoryApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[GET] All variable categories endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new VariableCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api.variableCategoryGetAll("").catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] All variable categories endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new VariableCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variableCategoryGetAll("bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Variable category endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new VariableCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variableCategoryPost(
        {
          category: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Variable category endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new VariableCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variableCategoryPost(
        {
          category: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] Variable category endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new VariableCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variableCategoryDelete("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] Variable category endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new VariableCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variableCategoryDelete(
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Variable category by guid endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new VariableCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variableCategoryGet("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Variable category by guid endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new VariableCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variableCategoryGet(
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Variable category endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new VariableCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variableCategoryPut(
        "00000000-0000-0000-0000-000000000000",
        {
          category: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Variable category endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new VariableCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variableCategoryPut(
        "00000000-0000-0000-0000-000000000000",
        {
          category: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
