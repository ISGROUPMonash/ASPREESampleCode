import { MongoDBSummaryApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[GET] Summary details endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new MongoDBSummaryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .mongoDBSummaryGetSummaryDetails("testProjectID", 123, "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Summary details endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new MongoDBSummaryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .mongoDBSummaryGetSummaryDetails("testProjectID", 123, "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
/*
API has been updated now with urls and parameters
test("[GET] Summary page form endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new MongoDBSummaryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .mongoDBSummaryGetSummaryPageForm(
        123,
          "00000000-0000-0000-0000-000000000000",
          "00000000-0000-0000-0000-000000000000",
          "00000000-0000-0000-0000-000000000000",
          123,
          "00000000-0000-0000-0000-000000000000",
          ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Summary page form endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new MongoDBSummaryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .mongoDBSummaryGetSummaryPageForm(
        123,
          "00000000-0000-0000-0000-000000000000",
          "00000000-0000-0000-0000-000000000000",
          "00000000-0000-0000-0000-000000000000",
        123,
          "00000000-0000-0000-0000-000000000000",
          "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
*/
test("[POST] Add summary page activity endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new MongoDBSummaryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .mongoDBSummaryAddSummaryPageActivity(
        {
          id: "5d4b784d9d1e3200d8c8ff6d",
          projectVersion: 1,
          activityDate: new Date("2019-08-08T01:18:05.1477694Z"),
          activityId: 1,
          activityName: "Example Activity",
          activityGuid: "474f5681-f2cd-40ac-8489-a0728e940d01",
          activityCompletedById: 1,
          activityCompletedByGuid: "dadcec2b-0e0b-48cb-bc45-45442f5e6fbf",
          activityCompletedByName: "Example User",
          personEntityId: 1,
          projectGuid: "3b237502-0d74-4410-b542-7506fa230f7a",
          projectName: "Example Project",
          createdByName: "SA User",
          createdDate: new Date("2019-08-08T01:18:05.1477694Z"),
          modifiedBy: "ef2c89c3-97b4-4772-a216-5efc87801dba",
          modifiedDate: new Date("2019-08-08T01:18:05.1477694Z"),
          modifiedByName: "SA User",
          summaryPageActivityFormsList: [
            {
              formId: 1,
              formGuid: "09b90a48-1cd7-4470-8f6b-db62ac85c830",
              formTitle: "Example Form",
              formStatusId: 3,
              formStatusName: "Draft"
            }
          ],
          linkedProjectName: "Example Project",
          linkedProjectGuid: "36d4ffb7-8ab3-468d-bff3-72bd244466ce"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Add summary page activity endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new MongoDBSummaryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .mongoDBSummaryAddSummaryPageActivity(
        {
          id: "5d4b784d9d1e3200d8c8ff6d",
          projectVersion: 1,
          activityDate: new Date("2019-08-08T01:18:05.1477694Z"),
          activityId: 1,
          activityName: "Example Activity",
          activityGuid: "474f5681-f2cd-40ac-8489-a0728e940d01",
          activityCompletedById: 1,
          activityCompletedByGuid: "dadcec2b-0e0b-48cb-bc45-45442f5e6fbf",
          activityCompletedByName: "Example User",
          personEntityId: 1,
          projectGuid: "3b237502-0d74-4410-b542-7506fa230f7a",
          projectName: "Example Project",
          createdByName: "SA User",
          createdDate: new Date("2019-08-08T01:18:05.1477694Z"),
          modifiedBy: "ef2c89c3-97b4-4772-a216-5efc87801dba",
          modifiedDate: new Date("2019-08-08T01:18:05.1477694Z"),
          modifiedByName: "SA User",
          summaryPageActivityFormsList: [
            {
              formId: 1,
              formGuid: "09b90a48-1cd7-4470-8f6b-db62ac85c830",
              formTitle: "Example Form",
              formStatusId: 3,
              formStatusName: "Draft"
            }
          ],
          linkedProjectName: "Example Project",
          linkedProjectGuid: "36d4ffb7-8ab3-468d-bff3-72bd244466ce"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Edit summary page activity endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new MongoDBSummaryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .mongoDBSummaryEditSummaryPageActivity(
        "testID",
        {
          id: "5d4b784d9d1e3200d8c8ff6d",
          projectVersion: 1,
          activityDate: new Date("2019-08-08T01:18:05.1477694Z"),
          activityId: 1,
          activityName: "Example Activity",
          activityGuid: "474f5681-f2cd-40ac-8489-a0728e940d01",
          activityCompletedById: 1,
          activityCompletedByGuid: "dadcec2b-0e0b-48cb-bc45-45442f5e6fbf",
          activityCompletedByName: "Example User",
          personEntityId: 1,
          projectGuid: "3b237502-0d74-4410-b542-7506fa230f7a",
          projectName: "Example Project",
          createdByName: "SA User",
          createdDate: new Date("2019-08-08T01:18:05.1477694Z"),
          modifiedBy: "ef2c89c3-97b4-4772-a216-5efc87801dba",
          modifiedDate: new Date("2019-08-08T01:18:05.1477694Z"),
          modifiedByName: "SA User",
          summaryPageActivityFormsList: [
            {
              formId: 1,
              formGuid: "09b90a48-1cd7-4470-8f6b-db62ac85c830",
              formTitle: "Example Form",
              formStatusId: 3,
              formStatusName: "Draft"
            }
          ],
          linkedProjectName: "Example Project",
          linkedProjectGuid: "36d4ffb7-8ab3-468d-bff3-72bd244466ce"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Edit summary page activity endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new MongoDBSummaryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .mongoDBSummaryEditSummaryPageActivity(
        "testID",
        {
          id: "5d4b784d9d1e3200d8c8ff6d",
          projectVersion: 1,
          activityDate: new Date("2019-08-08T01:18:05.1477694Z"),
          activityId: 1,
          activityName: "Example Activity",
          activityGuid: "474f5681-f2cd-40ac-8489-a0728e940d01",
          activityCompletedById: 1,
          activityCompletedByGuid: "dadcec2b-0e0b-48cb-bc45-45442f5e6fbf",
          activityCompletedByName: "Example User",
          personEntityId: 1,
          projectGuid: "3b237502-0d74-4410-b542-7506fa230f7a",
          projectName: "Example Project",
          createdByName: "SA User",
          createdDate: new Date("2019-08-08T01:18:05.1477694Z"),
          modifiedBy: "ef2c89c3-97b4-4772-a216-5efc87801dba",
          modifiedDate: new Date("2019-08-08T01:18:05.1477694Z"),
          modifiedByName: "SA User",
          summaryPageActivityFormsList: [
            {
              formId: 1,
              formGuid: "09b90a48-1cd7-4470-8f6b-db62ac85c830",
              formTitle: "Example Form",
              formStatusId: 3,
              formStatusName: "Draft"
            }
          ],
          linkedProjectName: "Example Project",
          linkedProjectGuid: "36d4ffb7-8ab3-468d-bff3-72bd244466ce"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] Summary page activity endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new MongoDBSummaryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .mongoDBSummaryDeleteSummaryPageActivity("testID", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] Summary page activity endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new MongoDBSummaryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .mongoDBSummaryDeleteSummaryPageActivity("testID", "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
