import { AuthenticationTypeApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[GET] AuthenticationType/GetAuthenticationTypeByState/{state} endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new AuthenticationTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .authenticationTypeGetAuthenticationTypeByState("")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] AuthenticationType/GetAuthenticationTypeByState/{state} endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new AuthenticationTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .authenticationTypeGetAuthenticationTypeByState("")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] AuthenticationType endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new AuthenticationTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api.authenticationTypeGetAll("").catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] AuthenticationType endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new AuthenticationTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .authenticationTypeGetAll("bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] AuthenticationType endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new AuthenticationTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .authenticationTypePost(
        {
          userName: "string",
          authTypeName: "string",
          authType: 0,
          domain: "string",
          clientId: "string",
          clientSecret: "string",
          scope: "string",
          state: "string",
          authenticationProviderClaim: "string",
          authorizeEndpoint: "string",
          tokenEndpoint: "string",
          introspectEndpoint: "string",
          revokeEndpoint: "string",
          logoutEndpoint: "string",
          keysEndpoint: "string",
          userinfoEndpoint: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] AuthenticationType endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new AuthenticationTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .authenticationTypePost(
        {
          userName: "string",
          authTypeName: "string",
          authType: 0,
          domain: "string",
          clientId: "string",
          clientSecret: "string",
          scope: "string",
          state: "string",
          authenticationProviderClaim: "string",
          authorizeEndpoint: "string",
          tokenEndpoint: "string",
          introspectEndpoint: "string",
          revokeEndpoint: "string",
          logoutEndpoint: "string",
          keysEndpoint: "string",
          userinfoEndpoint: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] AuthenticationType/{guid} endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new AuthenticationTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .authenticationTypeDelete("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] AuthenticationType/{guid} endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new AuthenticationTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .authenticationTypeDelete(
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] AuthenticationType/{guid} endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new AuthenticationTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .authenticationTypeGet("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] AuthenticationType/{guid} endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new AuthenticationTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .authenticationTypeGet(
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] AuthenticationType/{guid} endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new AuthenticationTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .authenticationTypePut(
        "00000000-0000-0000-0000-000000000000",
        {
          id: 0,
          userName: "string",
          authTypeName: "string",
          authType: 0,
          domain: "string",
          clientId: "string",
          clientSecret: "string",
          scope: "string",
          state: "string",
          guid: "00000000-0000-0000-0000-000000000000",
          authenticationProviderClaim: "string",
          authorizeEndpoint: "string",
          tokenEndpoint: "string",
          introspectEndpoint: "string",
          revokeEndpoint: "string",
          logoutEndpoint: "string",
          keysEndpoint: "string",
          userinfoEndpoint: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] AuthenticationType/{guid} endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new AuthenticationTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .authenticationTypePut(
        "00000000-0000-0000-0000-000000000000",
        {
          id: 0,
          userName: "string",
          authTypeName: "string",
          authType: 0,
          domain: "string",
          clientId: "string",
          clientSecret: "string",
          scope: "string",
          state: "string",
          guid: "00000000-0000-0000-0000-000000000000",
          authenticationProviderClaim: "string",
          authorizeEndpoint: "string",
          tokenEndpoint: "string",
          introspectEndpoint: "string",
          revokeEndpoint: "string",
          logoutEndpoint: "string",
          keysEndpoint: "string",
          userinfoEndpoint: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
