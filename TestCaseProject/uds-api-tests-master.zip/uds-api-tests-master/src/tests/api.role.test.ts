import { RoleApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[GET] Get all roles endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new RoleApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api.roleGetAll("").catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Get all roles endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new RoleApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api.roleGetAll("bad auth header").catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Role endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new RoleApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .rolePost(
        {
          name: "string",
          privileges: ["00000000-0000-0000-0000-000000000000"],
          tenantId: "00000000-0000-0000-0000-000000000000"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Role endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new RoleApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .rolePost(
        {
          name: "string",
          privileges: ["00000000-0000-0000-0000-000000000000"],
          tenantId: "00000000-0000-0000-0000-000000000000"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] Role endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new RoleApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .roleDelete("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] Role endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new RoleApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .roleDelete("00000000-0000-0000-0000-000000000000", "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Role endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new RoleApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .roleGet("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new RoleApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .roleGet("00000000-0000-0000-0000-000000000000", "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Role endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new RoleApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .rolePut(
        "00000000-0000-0000-0000-000000000000",
        {
          name: "string",
          privileges: ["00000000-0000-0000-0000-000000000000"]
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Role endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new RoleApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .rolePut(
        "00000000-0000-0000-0000-000000000000",
        {
          name: "string",
          privileges: ["00000000-0000-0000-0000-000000000000"]
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
