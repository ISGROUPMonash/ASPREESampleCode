import { VariableApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[GET] Project builder variables endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new VariableApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variableProjectBuilderVariables(
        "dc7356c7-11d8-4499-8daf-4e53b185a340",
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Project builder variables endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new VariableApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variableProjectBuilderVariables(
        "dc7356c7-11d8-4499-8daf-4e53b185a340",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] All variables for form page endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new VariableApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variableGetAllVariables("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] All variables for form page endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new VariableApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variableGetAllVariables(
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] All variables endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new VariableApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api.variableGetAll("").catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] All variables endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new VariableApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variableGetAll("bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Variable endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new VariableApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variablePost(
        {
          variableName: "string",
          variableLabel: "string",
          question: "string",
          values: ["string"],
          valueDescription: "string",
          helpText: "string",
          variableTypeId: "00000000-0000-0000-0000-000000000000",
          validationMessage: "string",
          requiredMessage: "string",
          minRange: 0,
          maxRange: 0,
          regEx: "string",
          isSoftRange: true,
          validationRuleId: "00000000-0000-0000-0000-000000000000",
          dependentVariableId: "00000000-0000-0000-0000-000000000000",
          isRequired: true,
          canCollectMultiple: true,
          variableCategoryId: "00000000-0000-0000-0000-000000000000",
          isApproved: true,
          comment: "string",
          variableRoles: ["00000000-0000-0000-0000-000000000000"],
          validationRuleIds: ["00000000-0000-0000-0000-000000000000"],
          customRegEx: "string",
          variableValueDescription: ["string"],
          outsideRangeValidation: "string",
          missingValidation: "string",
          lookupEntityType: "00000000-0000-0000-0000-000000000000",
          lookupEntitySubtype: "00000000-0000-0000-0000-000000000000",
          dateFormat: "string",
          canFutureDate: true
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Variable endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new VariableApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variablePost(
        {
          variableName: "string",
          variableLabel: "string",
          question: "string",
          values: ["string"],
          valueDescription: "string",
          helpText: "string",
          variableTypeId: "00000000-0000-0000-0000-000000000000",
          validationMessage: "string",
          requiredMessage: "string",
          minRange: 0,
          maxRange: 0,
          regEx: "string",
          isSoftRange: true,
          validationRuleId: "00000000-0000-0000-0000-000000000000",
          dependentVariableId: "00000000-0000-0000-0000-000000000000",
          isRequired: true,
          canCollectMultiple: true,
          variableCategoryId: "00000000-0000-0000-0000-000000000000",
          isApproved: true,
          comment: "string",
          variableRoles: ["00000000-0000-0000-0000-000000000000"],
          validationRuleIds: ["00000000-0000-0000-0000-000000000000"],
          customRegEx: "string",
          variableValueDescription: ["string"],
          outsideRangeValidation: "string",
          missingValidation: "string",
          lookupEntityType: "00000000-0000-0000-0000-000000000000",
          lookupEntitySubtype: "00000000-0000-0000-0000-000000000000",
          dateFormat: "string",
          canFutureDate: true
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] Variable endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new VariableApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variableDelete("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] Variable endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new VariableApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variableDelete("00000000-0000-0000-0000-000000000000", "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Variable by guid endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new VariableApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variableGet("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Variable by guid endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new VariableApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variableGet("00000000-0000-0000-0000-000000000000", "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Variable endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new VariableApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variablePut(
        "00000000-0000-0000-0000-000000000000",
        {
          variableName: "string",
          variableLabel: "string",
          question: "string",
          values: ["string"],
          valueDescription: "string",
          helpText: "string",
          variableTypeId: "00000000-0000-0000-0000-000000000000",
          validationMessage: "string",
          requiredMessage: "string",
          minRange: 0,
          maxRange: 0,
          regEx: "string",
          isSoftRange: true,
          validationRuleId: "00000000-0000-0000-0000-000000000000",
          dependentVariableId: "00000000-0000-0000-0000-000000000000",
          isRequired: true,
          canCollectMultiple: true,
          variableCategoryId: "00000000-0000-0000-0000-000000000000",
          isApproved: true,
          guid: "00000000-0000-0000-0000-000000000000",
          variableRoles: ["00000000-0000-0000-0000-000000000000"],
          comment: "string",
          validationRuleIds: ["00000000-0000-0000-0000-000000000000"],
          customRegEx: "string",
          variableValueDescription: ["string"],
          isVariableLogTable: true,
          outsideRangeValidation: "string",
          missingValidation: "string",
          lookupEntityType: "00000000-0000-0000-0000-000000000000",
          lookupEntitySubtype: "00000000-0000-0000-0000-000000000000",
          dateFormat: "string",
          canFutureDate: true
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Variable endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new VariableApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .variablePut(
        "00000000-0000-0000-0000-000000000000",
        {
          variableName: "string",
          variableLabel: "string",
          question: "string",
          values: ["string"],
          valueDescription: "string",
          helpText: "string",
          variableTypeId: "00000000-0000-0000-0000-000000000000",
          validationMessage: "string",
          requiredMessage: "string",
          minRange: 0,
          maxRange: 0,
          regEx: "string",
          isSoftRange: true,
          validationRuleId: "00000000-0000-0000-0000-000000000000",
          dependentVariableId: "00000000-0000-0000-0000-000000000000",
          isRequired: true,
          canCollectMultiple: true,
          variableCategoryId: "00000000-0000-0000-0000-000000000000",
          isApproved: true,
          guid: "00000000-0000-0000-0000-000000000000",
          variableRoles: ["00000000-0000-0000-0000-000000000000"],
          comment: "string",
          validationRuleIds: ["00000000-0000-0000-0000-000000000000"],
          customRegEx: "string",
          variableValueDescription: ["string"],
          isVariableLogTable: true,
          outsideRangeValidation: "string",
          missingValidation: "string",
          lookupEntityType: "00000000-0000-0000-0000-000000000000",
          lookupEntitySubtype: "00000000-0000-0000-0000-000000000000",
          dateFormat: "string",
          canFutureDate: true
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
