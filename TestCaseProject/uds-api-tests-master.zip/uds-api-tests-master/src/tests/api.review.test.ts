import { ReviewApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[GET] Project mongo endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewGetProjectMongo("testprojectID", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Project mongo endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewGetProjectMongo("testprojectID", "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] All deployed project endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api.reviewGetAllDeployedProject("").catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] All deployed project endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewGetAllDeployedProject("bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Check entity linked project endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewCheckEntityLinkedProject("testprojectID", 123, "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Check entity linked project endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewCheckEntityLinkedProject("testprojectID", 123, "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Search entities endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewSearchEntities(
        {
          searchVariables: [
            {
              key: 0,
              value: "string"
            }
          ],
          projectId: "00000000-0000-0000-0000-000000000000",
          formId: "00000000-0000-0000-0000-000000000000",
          formTitle: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Search entities endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewSearchEntities(
        {
          searchVariables: [
            {
              key: 0,
              value: "string"
            }
          ],
          projectId: "00000000-0000-0000-0000-000000000000",
          formId: "00000000-0000-0000-0000-000000000000",
          formTitle: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] All summary page activity endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewGetAllSummaryPageActivity("testentID", "testprojectID", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] All summary page activity endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewGetAllSummaryPageActivity(
        "testentID",
        "testprojectID",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Activity form by searched entity endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewGetActivityFormBySearchedEntity(
        123,
        "testformID",
        "testactivityID",
        123,
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Activity form by searched entity endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewGetActivityFormBySearchedEntity(
        123,
        "testformID",
        "testactivityID",
        123,
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Form data entry save endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewFormDataEntrySave(
        {
          id: 0,
          projectId: "00000000-0000-0000-0000-000000000000",
          entityId: "00000000-0000-0000-0000-000000000000",
          subjectId: 0,
          status: 0,
          createdBy: "00000000-0000-0000-0000-000000000000",
          createdDate: new Date("2019-08-09T00:10:14.236Z"),
          modifiedBy: 0,
          modifiedDate: new Date("2019-08-09T00:10:14.236Z"),
          deactivatedBy: 0,
          dateDeactivated: new Date("2019-08-09T00:10:14.236Z"),
          guid: "00000000-0000-0000-0000-000000000000",
          activityId: "00000000-0000-0000-0000-000000000000",
          tenantId: "00000000-0000-0000-0000-000000000000",
          activity: {
            activityName: "string",
            dependentActivityId: "00000000-0000-0000-0000-000000000000",
            activityCategoryId: "00000000-0000-0000-0000-000000000000",
            startDate: new Date("2019-08-09T00:10:14.236Z"),
            endDate: new Date("2019-08-09T00:10:14.236Z"),
            scheduleType: 0,
            activityStatusId: "00000000-0000-0000-0000-000000000000",
            activityStatusName: "string",
            createdBy: "00000000-0000-0000-0000-000000000000",
            createdDate: new Date("2019-08-09T00:10:14.236Z"),
            modifiedBy: "00000000-0000-0000-0000-000000000000",
            modifiedDate: new Date("2019-08-09T00:10:14.236Z"),
            deactivatedBy: "00000000-0000-0000-0000-000000000000",
            dateDeactivated: new Date("2019-08-09T00:10:14.236Z"),
            guid: "00000000-0000-0000-0000-000000000000",
            projectId: "00000000-0000-0000-0000-000000000000",
            tenantId: "00000000-0000-0000-0000-000000000000",
            forms: [
              {
                id: "00000000-0000-0000-0000-000000000000",
                formTitle: "string",
                status: "string",
                roles: ["00000000-0000-0000-0000-000000000000"]
              }
            ],
            entityTypes: ["00000000-0000-0000-0000-000000000000"],
            activityRoles: ["00000000-0000-0000-0000-000000000000"],
            activityRoleNames: ["string"],
            isDefaultActivity: 0,
            isActivityRequireAnEntity: true,
            repeatationCount: 0,
            repeatationOffset: 0
          },
          formDataEntryVariable: [
            {
              id: 0,
              variableId: 0,
              selectedValues: "string",
              selectedValuesInt: 0,
              selectedValuesFloat: 0,
              formDataEntryId: 0,
              createdBy: 0,
              createdDate: new Date("2019-08-09T00:10:14.236Z"),
              modifiedBy: 0,
              modifiedDate: new Date("2019-08-09T00:10:14.236Z"),
              deactivatedBy: 0,
              dateDeactivated: new Date("2019-08-09T00:10:14.236Z"),
              guid: "00000000-0000-0000-0000-000000000000",
              variableName: "string",
              formId: 0,
              parentId: 0,
              activityId: 0,
              formGuid: "00000000-0000-0000-0000-000000000000",
              activityGuid: "00000000-0000-0000-0000-000000000000",
              formDataEntryStatus: 0,
              formTitle: "string"
            }
          ],
          formId: "00000000-0000-0000-0000-000000000000",
          participantId: "string",
          formTitle: "string",
          thisUserId: 0,
          parentEntityNumber: 0,
          projectDeployStatus: 0,
          projectDeployedId: "string",
          projectDeployedVersion: "string",
          summaryPageActivityObjId: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Form data entry save endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewFormDataEntrySave(
        {
          id: 0,
          projectId: "00000000-0000-0000-0000-000000000000",
          entityId: "00000000-0000-0000-0000-000000000000",
          subjectId: 0,
          status: 0,
          createdBy: "00000000-0000-0000-0000-000000000000",
          createdDate: new Date("2019-08-09T00:10:14.236Z"),
          modifiedBy: 0,
          modifiedDate: new Date("2019-08-09T00:10:14.236Z"),
          deactivatedBy: 0,
          dateDeactivated: new Date("2019-08-09T00:10:14.236Z"),
          guid: "00000000-0000-0000-0000-000000000000",
          activityId: "00000000-0000-0000-0000-000000000000",
          tenantId: "00000000-0000-0000-0000-000000000000",
          activity: {
            activityName: "string",
            dependentActivityId: "00000000-0000-0000-0000-000000000000",
            activityCategoryId: "00000000-0000-0000-0000-000000000000",
            startDate: new Date("2019-08-09T00:10:14.236Z"),
            endDate: new Date("2019-08-09T00:10:14.236Z"),
            scheduleType: 0,
            activityStatusId: "00000000-0000-0000-0000-000000000000",
            activityStatusName: "string",
            createdBy: "00000000-0000-0000-0000-000000000000",
            createdDate: new Date("2019-08-09T00:10:14.236Z"),
            modifiedBy: "00000000-0000-0000-0000-000000000000",
            modifiedDate: new Date("2019-08-09T00:10:14.236Z"),
            deactivatedBy: "00000000-0000-0000-0000-000000000000",
            dateDeactivated: new Date("2019-08-09T00:10:14.236Z"),
            guid: "00000000-0000-0000-0000-000000000000",
            projectId: "00000000-0000-0000-0000-000000000000",
            tenantId: "00000000-0000-0000-0000-000000000000",
            forms: [
              {
                id: "00000000-0000-0000-0000-000000000000",
                formTitle: "string",
                status: "string",
                roles: ["00000000-0000-0000-0000-000000000000"]
              }
            ],
            entityTypes: ["00000000-0000-0000-0000-000000000000"],
            activityRoles: ["00000000-0000-0000-0000-000000000000"],
            activityRoleNames: ["string"],
            isDefaultActivity: 0,
            isActivityRequireAnEntity: true,
            repeatationCount: 0,
            repeatationOffset: 0
          },
          formDataEntryVariable: [
            {
              id: 0,
              variableId: 0,
              selectedValues: "string",
              selectedValuesInt: 0,
              selectedValuesFloat: 0,
              formDataEntryId: 0,
              createdBy: 0,
              createdDate: new Date("2019-08-09T00:10:14.236Z"),
              modifiedBy: 0,
              modifiedDate: new Date("2019-08-09T00:10:14.236Z"),
              deactivatedBy: 0,
              dateDeactivated: new Date("2019-08-09T00:10:14.236Z"),
              guid: "00000000-0000-0000-0000-000000000000",
              variableName: "string",
              formId: 0,
              parentId: 0,
              activityId: 0,
              formGuid: "00000000-0000-0000-0000-000000000000",
              activityGuid: "00000000-0000-0000-0000-000000000000",
              formDataEntryStatus: 0,
              formTitle: "string"
            }
          ],
          formId: "00000000-0000-0000-0000-000000000000",
          participantId: "string",
          formTitle: "string",
          thisUserId: 0,
          parentEntityNumber: 0,
          projectDeployStatus: 0,
          projectDeployedId: "string",
          projectDeployedVersion: "string",
          summaryPageActivityObjId: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] form data entry edit endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewFormDataEntryEdit(
        "00000000-0000-0000-0000-000000000000",
        {
          id: 0,
          projectId: "00000000-0000-0000-0000-000000000000",
          entityId: "00000000-0000-0000-0000-000000000000",
          subjectId: 0,
          status: 0,
          createdBy: "00000000-0000-0000-0000-000000000000",
          createdDate: new Date("2019-08-09T00:10:14.236Z"),
          modifiedBy: 0,
          modifiedDate: new Date("2019-08-09T00:10:14.236Z"),
          deactivatedBy: 0,
          dateDeactivated: new Date("2019-08-09T00:10:14.236Z"),
          guid: "00000000-0000-0000-0000-000000000000",
          activityId: "00000000-0000-0000-0000-000000000000",
          tenantId: "00000000-0000-0000-0000-000000000000",
          activity: {
            activityName: "string",
            dependentActivityId: "00000000-0000-0000-0000-000000000000",
            activityCategoryId: "00000000-0000-0000-0000-000000000000",
            startDate: new Date("2019-08-09T00:10:14.236Z"),
            endDate: new Date("2019-08-09T00:10:14.236Z"),
            scheduleType: 0,
            activityStatusId: "00000000-0000-0000-0000-000000000000",
            activityStatusName: "string",
            createdBy: "00000000-0000-0000-0000-000000000000",
            createdDate: new Date("2019-08-09T00:10:14.236Z"),
            modifiedBy: "00000000-0000-0000-0000-000000000000",
            modifiedDate: new Date("2019-08-09T00:10:14.236Z"),
            deactivatedBy: "00000000-0000-0000-0000-000000000000",
            dateDeactivated: new Date("2019-08-09T00:10:14.236Z"),
            guid: "00000000-0000-0000-0000-000000000000",
            projectId: "00000000-0000-0000-0000-000000000000",
            tenantId: "00000000-0000-0000-0000-000000000000",
            forms: [
              {
                id: "00000000-0000-0000-0000-000000000000",
                formTitle: "string",
                status: "string",
                roles: ["00000000-0000-0000-0000-000000000000"]
              }
            ],
            entityTypes: ["00000000-0000-0000-0000-000000000000"],
            activityRoles: ["00000000-0000-0000-0000-000000000000"],
            activityRoleNames: ["string"],
            isDefaultActivity: 0,
            isActivityRequireAnEntity: true,
            repeatationCount: 0,
            repeatationOffset: 0
          },
          formDataEntryVariable: [
            {
              id: 0,
              variableId: 0,
              selectedValues: "string",
              selectedValuesInt: 0,
              selectedValuesFloat: 0,
              formDataEntryId: 0,
              createdBy: 0,
              createdDate: new Date("2019-08-09T00:10:14.236Z"),
              modifiedBy: 0,
              modifiedDate: new Date("2019-08-09T00:10:14.236Z"),
              deactivatedBy: 0,
              dateDeactivated: new Date("2019-08-09T00:10:14.236Z"),
              guid: "00000000-0000-0000-0000-000000000000",
              variableName: "string",
              formId: 0,
              parentId: 0,
              activityId: 0,
              formGuid: "00000000-0000-0000-0000-000000000000",
              activityGuid: "00000000-0000-0000-0000-000000000000",
              formDataEntryStatus: 0,
              formTitle: "string"
            }
          ],
          formId: "00000000-0000-0000-0000-000000000000",
          participantId: "string",
          formTitle: "string",
          thisUserId: 0,
          parentEntityNumber: 0,
          projectDeployStatus: 0,
          projectDeployedId: "string",
          projectDeployedVersion: "string",
          summaryPageActivityObjId: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] form data entry edit endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewFormDataEntryEdit(
        "00000000-0000-0000-0000-000000000000",
        {
          id: 0,
          projectId: "00000000-0000-0000-0000-000000000000",
          entityId: "00000000-0000-0000-0000-000000000000",
          subjectId: 0,
          status: 0,
          createdBy: "00000000-0000-0000-0000-000000000000",
          createdDate: new Date("2019-08-09T00:10:14.236Z"),
          modifiedBy: 0,
          modifiedDate: new Date("2019-08-09T00:10:14.236Z"),
          deactivatedBy: 0,
          dateDeactivated: new Date("2019-08-09T00:10:14.236Z"),
          guid: "00000000-0000-0000-0000-000000000000",
          activityId: "00000000-0000-0000-0000-000000000000",
          tenantId: "00000000-0000-0000-0000-000000000000",
          activity: {
            activityName: "string",
            dependentActivityId: "00000000-0000-0000-0000-000000000000",
            activityCategoryId: "00000000-0000-0000-0000-000000000000",
            startDate: new Date("2019-08-09T00:10:14.236Z"),
            endDate: new Date("2019-08-09T00:10:14.236Z"),
            scheduleType: 0,
            activityStatusId: "00000000-0000-0000-0000-000000000000",
            activityStatusName: "string",
            createdBy: "00000000-0000-0000-0000-000000000000",
            createdDate: new Date("2019-08-09T00:10:14.236Z"),
            modifiedBy: "00000000-0000-0000-0000-000000000000",
            modifiedDate: new Date("2019-08-09T00:10:14.236Z"),
            deactivatedBy: "00000000-0000-0000-0000-000000000000",
            dateDeactivated: new Date("2019-08-09T00:10:14.236Z"),
            guid: "00000000-0000-0000-0000-000000000000",
            projectId: "00000000-0000-0000-0000-000000000000",
            tenantId: "00000000-0000-0000-0000-000000000000",
            forms: [
              {
                id: "00000000-0000-0000-0000-000000000000",
                formTitle: "string",
                status: "string",
                roles: ["00000000-0000-0000-0000-000000000000"]
              }
            ],
            entityTypes: ["00000000-0000-0000-0000-000000000000"],
            activityRoles: ["00000000-0000-0000-0000-000000000000"],
            activityRoleNames: ["string"],
            isDefaultActivity: 0,
            isActivityRequireAnEntity: true,
            repeatationCount: 0,
            repeatationOffset: 0
          },
          formDataEntryVariable: [
            {
              id: 0,
              variableId: 0,
              selectedValues: "string",
              selectedValuesInt: 0,
              selectedValuesFloat: 0,
              formDataEntryId: 0,
              createdBy: 0,
              createdDate: new Date("2019-08-09T00:10:14.236Z"),
              modifiedBy: 0,
              modifiedDate: new Date("2019-08-09T00:10:14.236Z"),
              deactivatedBy: 0,
              dateDeactivated: new Date("2019-08-09T00:10:14.236Z"),
              guid: "00000000-0000-0000-0000-000000000000",
              variableName: "string",
              formId: 0,
              parentId: 0,
              activityId: 0,
              formGuid: "00000000-0000-0000-0000-000000000000",
              activityGuid: "00000000-0000-0000-0000-000000000000",
              formDataEntryStatus: 0,
              formTitle: "string"
            }
          ],
          formId: "00000000-0000-0000-0000-000000000000",
          participantId: "string",
          formTitle: "string",
          thisUserId: 0,
          parentEntityNumber: 0,
          projectDeployStatus: 0,
          projectDeployedId: "string",
          projectDeployedVersion: "string",
          summaryPageActivityObjId: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Search test entities endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewSearchTestEntities(
        {
          searchVariables: [
            {
              key: 0,
              value: "string"
            }
          ],
          projectId: "00000000-0000-0000-0000-000000000000",
          formId: "00000000-0000-0000-0000-000000000000",
          formTitle: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Search test entities endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewSearchTestEntities(
        {
          searchVariables: [
            {
              key: 0,
              value: "string"
            }
          ],
          projectId: "00000000-0000-0000-0000-000000000000",
          formId: "00000000-0000-0000-0000-000000000000",
          formTitle: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Summary details endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewGetSummaryDetails("testprojectID", 123, "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Summary details endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewGetSummaryDetails("testprojectID", 123, "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Summary page form endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewGetSummaryPageForm(
        123,
          "00000000-0000-0000-0000-000000000000",
          "00000000-0000-0000-0000-000000000000",
          "00000000-0000-0000-0000-000000000000",
        123,
        "testsummarypageID",
          "00000000-0000-0000-0000-000000000000", ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Summary page form endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewGetSummaryPageForm(
          123,
          "00000000-0000-0000-0000-000000000000",
          "00000000-0000-0000-0000-000000000000",
          "00000000-0000-0000-0000-000000000000",
          123,
          "testsummarypageID",
          "00000000-0000-0000-0000-000000000000", "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Add summary page activity Mongo endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewAddSummaryPageActivityMongo(
        {
          id: "5d4cb9e59d1e321898dfbc6d",
          projectVersion: 1,
          activityDate: new Date("2019-08-09T00:10:13.3413999Z"),
          activityId: 1,
          activityName: "Example Activity",
          activityGuid: "f6404d7a-825a-47eb-bd5c-eca4d562dc4a",
          activityCompletedById: 1,
          activityCompletedByGuid: "447fc1f7-1f7e-411d-b671-5c5dacf5e9a3",
          activityCompletedByName: "Example User",
          personEntityId: 1,
          projectGuid: "e93e5563-67c1-465d-bc16-1056fa7d2d11",
          projectName: "Example Project",
          createdByName: "SA User",
          createdDate: new Date("2019-08-09T00:10:13.3413999Z"),
          modifiedBy: "39a7f81c-a4be-43b9-a2d6-23d8cf46dbe4",
          modifiedDate: new Date("2019-08-09T00:10:13.3413999Z"),
          modifiedByName: "SA User",
          summaryPageActivityFormsList: [
            {
              formId: 1,
              formGuid: "996e30d9-5292-4fc7-8505-efa7a445de9b",
              formTitle: "Example Form",
              formStatusId: 3,
              formStatusName: "Draft"
            }
          ],
          linkedProjectName: "Example Project",
          linkedProjectGuid: "8110a630-4ae0-452c-879d-86cc4f42aad4"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Add summary page activity Mongo endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewAddSummaryPageActivityMongo(
        {
          id: "5d4cb9e59d1e321898dfbc6d",
          projectVersion: 1,
          activityDate: new Date("2019-08-09T00:10:13.3413999Z"),
          activityId: 1,
          activityName: "Example Activity",
          activityGuid: "f6404d7a-825a-47eb-bd5c-eca4d562dc4a",
          activityCompletedById: 1,
          activityCompletedByGuid: "447fc1f7-1f7e-411d-b671-5c5dacf5e9a3",
          activityCompletedByName: "Example User",
          personEntityId: 1,
          projectGuid: "e93e5563-67c1-465d-bc16-1056fa7d2d11",
          projectName: "Example Project",
          createdByName: "SA User",
          createdDate: new Date("2019-08-09T00:10:13.3413999Z"),
          modifiedBy: "39a7f81c-a4be-43b9-a2d6-23d8cf46dbe4",
          modifiedDate: new Date("2019-08-09T00:10:13.3413999Z"),
          modifiedByName: "SA User",
          summaryPageActivityFormsList: [
            {
              formId: 1,
              formGuid: "996e30d9-5292-4fc7-8505-efa7a445de9b",
              formTitle: "Example Form",
              formStatusId: 3,
              formStatusName: "Draft"
            }
          ],
          linkedProjectName: "Example Project",
          linkedProjectGuid: "8110a630-4ae0-452c-879d-86cc4f42aad4"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Edit summary page activty endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewEditSummaryPageActivity(
        "testid",
        {
          id: "5d4cb9e59d1e321898dfbc6d",
          projectVersion: 1,
          activityDate: new Date("2019-08-09T00:10:13.3413999Z"),
          activityId: 1,
          activityName: "Example Activity",
          activityGuid: "f6404d7a-825a-47eb-bd5c-eca4d562dc4a",
          activityCompletedById: 1,
          activityCompletedByGuid: "447fc1f7-1f7e-411d-b671-5c5dacf5e9a3",
          activityCompletedByName: "Example User",
          personEntityId: 1,
          projectGuid: "e93e5563-67c1-465d-bc16-1056fa7d2d11",
          projectName: "Example Project",
          createdByName: "SA User",
          createdDate: new Date("2019-08-09T00:10:13.3413999Z"),
          modifiedBy: "39a7f81c-a4be-43b9-a2d6-23d8cf46dbe4",
          modifiedDate: new Date("2019-08-09T00:10:13.3413999Z"),
          modifiedByName: "SA User",
          summaryPageActivityFormsList: [
            {
              formId: 1,
              formGuid: "996e30d9-5292-4fc7-8505-efa7a445de9b",
              formTitle: "Example Form",
              formStatusId: 3,
              formStatusName: "Draft"
            }
          ],
          linkedProjectName: "Example Project",
          linkedProjectGuid: "8110a630-4ae0-452c-879d-86cc4f42aad4"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Edit summary page activty endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewEditSummaryPageActivity(
        "testid",
        {
          id: "5d4cb9e59d1e321898dfbc6d",
          projectVersion: 1,
          activityDate: new Date("2019-08-09T00:10:13.3413999Z"),
          activityId: 1,
          activityName: "Example Activity",
          activityGuid: "f6404d7a-825a-47eb-bd5c-eca4d562dc4a",
          activityCompletedById: 1,
          activityCompletedByGuid: "447fc1f7-1f7e-411d-b671-5c5dacf5e9a3",
          activityCompletedByName: "Example User",
          personEntityId: 1,
          projectGuid: "e93e5563-67c1-465d-bc16-1056fa7d2d11",
          projectName: "Example Project",
          createdByName: "SA User",
          createdDate: new Date("2019-08-09T00:10:13.3413999Z"),
          modifiedBy: "39a7f81c-a4be-43b9-a2d6-23d8cf46dbe4",
          modifiedDate: new Date("2019-08-09T00:10:13.3413999Z"),
          modifiedByName: "SA User",
          summaryPageActivityFormsList: [
            {
              formId: 1,
              formGuid: "996e30d9-5292-4fc7-8505-efa7a445de9b",
              formTitle: "Example Form",
              formStatusId: 3,
              formStatusName: "Draft"
            }
          ],
          linkedProjectName: "Example Project",
          linkedProjectGuid: "8110a630-4ae0-452c-879d-86cc4f42aad4"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] Summary page activity endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewDeleteSummaryPageActivity("testID", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] Summary page activity endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ReviewApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reviewDeleteSummaryPageActivity("testID", "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
