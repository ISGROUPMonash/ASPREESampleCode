import { ActionListApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[POST] AllActionListData endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ActionListApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .actionListAllActionListData(
        {
          draw: 0,
          length: 0,
          start: 0,
          projectId: "00000000-0000-0000-0000-000000000000",
          entityType: "string",
          entityNumber: "string",
          activity: "string",
          form: "string",
          formStatus: "string",
          loggedInUserGuid: "00000000-0000-0000-0000-000000000000"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] AllActionListData endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ActionListApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .actionListAllActionListData(
        {
          draw: 0,
          length: 0,
          start: 0,
          projectId: "00000000-0000-0000-0000-000000000000",
          entityType: "string",
          entityNumber: "string",
          activity: "string",
          form: "string",
          formStatus: "string",
          loggedInUserGuid: "00000000-0000-0000-0000-000000000000"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] CountAllActionList/{guid} endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ActionListApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .actionListCountAllActionList("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] CountAllActionList/{guid} endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ActionListApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .actionListCountAllActionList(
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] GetAllActionListActivities/{projectId} endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ActionListApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .actionListGetAllActionListActivities(
        "00000000-0000-0000-0000-000000000000",
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] GetAllActionListActivities/{projectId} endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ActionListApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .actionListGetAllActionListActivities(
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
