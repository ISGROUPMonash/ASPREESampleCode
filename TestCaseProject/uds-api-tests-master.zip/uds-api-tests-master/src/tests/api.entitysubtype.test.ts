import { EntitySubTypeApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[GET] EntitySubType endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new EntitySubTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api.entitySubTypeGetAll("").catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] EntitySubType endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new EntitySubTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .entitySubTypeGetAll("bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] EntitySubType endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new EntitySubTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .entitySubTypePost(
        {
          name: "Example EntitySubType",
          entityTypeId: "83bb13d0-927e-40e9-8f87-37f1a4cdc9be"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] EntitySubType endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new EntitySubTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .entitySubTypePost(
        {
          name: "Example EntitySubType",
          entityTypeId: "83bb13d0-927e-40e9-8f87-37f1a4cdc9be"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] EntitySubType/{guid} endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new EntitySubTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .entitySubTypeDelete("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] EntitySubType/{guid} endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new EntitySubTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .entitySubTypeDelete(
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] EntitySubType/{guid} endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new EntitySubTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .entitySubTypeGet("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] EntitySubType/{guid} endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new EntitySubTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .entitySubTypeGet(
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] EntitySubType/{guid} endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new EntitySubTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .entitySubTypePut(
        "00000000-0000-0000-0000-000000000000",
        {
          name: "Example EntitySubType",
          entityTypeId: "83bb13d0-927e-40e9-8f87-37f1a4cdc9be"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] EntitySubType/{guid} endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new EntitySubTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .entitySubTypePut(
        "00000000-0000-0000-0000-000000000000",
        {
          name: "Example EntitySubType",
          entityTypeId: "83bb13d0-927e-40e9-8f87-37f1a4cdc9be"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
