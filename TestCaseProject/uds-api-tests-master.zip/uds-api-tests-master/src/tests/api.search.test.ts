import { SearchApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[POST] Search entities endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new SearchApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .searchSearchEntities(
        {
          searchVariables: [
            {
              key: 0,
              value: "string"
            }
          ],
          projectId: "00000000-0000-0000-0000-000000000000",
          formId: "00000000-0000-0000-0000-000000000000",
          formTitle: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Search entities endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new SearchApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .searchSearchEntities(
        {
          searchVariables: [
            {
              key: 0,
              value: "string"
            }
          ],
          projectId: "00000000-0000-0000-0000-000000000000",
          formId: "00000000-0000-0000-0000-000000000000",
          formTitle: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Save entities endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new SearchApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .searchPost(
        {
          id: 0,
          projectId: "00000000-0000-0000-0000-000000000000",
          entityId: "00000000-0000-0000-0000-000000000000",
          subjectId: 0,
          status: 0,
          createdBy: "00000000-0000-0000-0000-000000000000",
          createdDate: new Date("2019-08-08T01:18:06.155Z"),
          modifiedBy: 0,
          modifiedDate: new Date("2019-08-08T01:18:06.155Z"),
          deactivatedBy: 0,
          dateDeactivated: new Date("2019-08-08T01:18:06.155Z"),
          guid: "00000000-0000-0000-0000-000000000000",
          activityId: "00000000-0000-0000-0000-000000000000",
          tenantId: "00000000-0000-0000-0000-000000000000",
          activity: {
            activityName: "string",
            dependentActivityId: "00000000-0000-0000-0000-000000000000",
            activityCategoryId: "00000000-0000-0000-0000-000000000000",
            startDate: new Date("2019-08-08T01:18:06.155Z"),
            endDate: new Date("2019-08-08T01:18:06.155Z"),
            scheduleType: 0,
            activityStatusId: "00000000-0000-0000-0000-000000000000",
            activityStatusName: "string",
            createdBy: "00000000-0000-0000-0000-000000000000",
            createdDate: new Date("2019-08-08T01:18:06.155Z"),
            modifiedBy: "00000000-0000-0000-0000-000000000000",
            modifiedDate: new Date("2019-08-08T01:18:06.155Z"),
            deactivatedBy: "00000000-0000-0000-0000-000000000000",
            dateDeactivated: new Date("2019-08-08T01:18:06.155Z"),
            guid: "00000000-0000-0000-0000-000000000000",
            projectId: "00000000-0000-0000-0000-000000000000",
            tenantId: "00000000-0000-0000-0000-000000000000",
            forms: [
              {
                id: "00000000-0000-0000-0000-000000000000",
                formTitle: "string",
                status: "string",
                roles: ["00000000-0000-0000-0000-000000000000"]
              }
            ],
            entityTypes: ["00000000-0000-0000-0000-000000000000"],
            activityRoles: ["00000000-0000-0000-0000-000000000000"],
            activityRoleNames: ["string"],
            isDefaultActivity: 0,
            isActivityRequireAnEntity: true,
            repeatationCount: 0,
            repeatationOffset: 0
          },
          formDataEntryVariable: [
            {
              id: 0,
              variableId: 0,
              selectedValues: "string",
              selectedValuesInt: 0,
              selectedValuesFloat: 0,
              formDataEntryId: 0,
              createdBy: 0,
              createdDate: new Date("2019-08-08T01:18:06.156Z"),
              modifiedBy: 0,
              modifiedDate: new Date("2019-08-08T01:18:06.156Z"),
              deactivatedBy: 0,
              dateDeactivated: new Date("2019-08-08T01:18:06.156Z"),
              guid: "00000000-0000-0000-0000-000000000000",
              variableName: "string",
              formId: 0,
              parentId: 0,
              activityId: 0,
              formGuid: "00000000-0000-0000-0000-000000000000",
              activityGuid: "00000000-0000-0000-0000-000000000000",
              formDataEntryStatus: 0,
              formTitle: "string"
            }
          ],
          formId: "00000000-0000-0000-0000-000000000000",
          participantId: "string",
          formTitle: "string",
          thisUserId: 0,
          parentEntityNumber: 0,
          projectDeployStatus: 0,
          projectDeployedId: "string",
          projectDeployedVersion: "string",
          summaryPageActivityObjId: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Save entities endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new SearchApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .searchPost(
        {
          id: 0,
          projectId: "00000000-0000-0000-0000-000000000000",
          entityId: "00000000-0000-0000-0000-000000000000",
          subjectId: 0,
          status: 0,
          createdBy: "00000000-0000-0000-0000-000000000000",
          createdDate: new Date("2019-08-08T01:18:06.155Z"),
          modifiedBy: 0,
          modifiedDate: new Date("2019-08-08T01:18:06.155Z"),
          deactivatedBy: 0,
          dateDeactivated: new Date("2019-08-08T01:18:06.155Z"),
          guid: "00000000-0000-0000-0000-000000000000",
          activityId: "00000000-0000-0000-0000-000000000000",
          tenantId: "00000000-0000-0000-0000-000000000000",
          activity: {
            activityName: "string",
            dependentActivityId: "00000000-0000-0000-0000-000000000000",
            activityCategoryId: "00000000-0000-0000-0000-000000000000",
            startDate: new Date("2019-08-08T01:18:06.155Z"),
            endDate: new Date("2019-08-08T01:18:06.155Z"),
            scheduleType: 0,
            activityStatusId: "00000000-0000-0000-0000-000000000000",
            activityStatusName: "string",
            createdBy: "00000000-0000-0000-0000-000000000000",
            createdDate: new Date("2019-08-08T01:18:06.155Z"),
            modifiedBy: "00000000-0000-0000-0000-000000000000",
            modifiedDate: new Date("2019-08-08T01:18:06.155Z"),
            deactivatedBy: "00000000-0000-0000-0000-000000000000",
            dateDeactivated: new Date("2019-08-08T01:18:06.155Z"),
            guid: "00000000-0000-0000-0000-000000000000",
            projectId: "00000000-0000-0000-0000-000000000000",
            tenantId: "00000000-0000-0000-0000-000000000000",
            forms: [
              {
                id: "00000000-0000-0000-0000-000000000000",
                formTitle: "string",
                status: "string",
                roles: ["00000000-0000-0000-0000-000000000000"]
              }
            ],
            entityTypes: ["00000000-0000-0000-0000-000000000000"],
            activityRoles: ["00000000-0000-0000-0000-000000000000"],
            activityRoleNames: ["string"],
            isDefaultActivity: 0,
            isActivityRequireAnEntity: true,
            repeatationCount: 0,
            repeatationOffset: 0
          },
          formDataEntryVariable: [
            {
              id: 0,
              variableId: 0,
              selectedValues: "string",
              selectedValuesInt: 0,
              selectedValuesFloat: 0,
              formDataEntryId: 0,
              createdBy: 0,
              createdDate: new Date("2019-08-08T01:18:06.156Z"),
              modifiedBy: 0,
              modifiedDate: new Date("2019-08-08T01:18:06.156Z"),
              deactivatedBy: 0,
              dateDeactivated: new Date("2019-08-08T01:18:06.156Z"),
              guid: "00000000-0000-0000-0000-000000000000",
              variableName: "string",
              formId: 0,
              parentId: 0,
              activityId: 0,
              formGuid: "00000000-0000-0000-0000-000000000000",
              activityGuid: "00000000-0000-0000-0000-000000000000",
              formDataEntryStatus: 0,
              formTitle: "string"
            }
          ],
          formId: "00000000-0000-0000-0000-000000000000",
          participantId: "string",
          formTitle: "string",
          thisUserId: 0,
          parentEntityNumber: 0,
          projectDeployStatus: 0,
          projectDeployedId: "string",
          projectDeployedVersion: "string",
          summaryPageActivityObjId: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Edit entities endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new SearchApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .searchPut(
        "00000000-0000-0000-0000-000000000000",
        {
          id: 0,
          projectId: "00000000-0000-0000-0000-000000000000",
          entityId: "00000000-0000-0000-0000-000000000000",
          subjectId: 0,
          status: 0,
          createdBy: "00000000-0000-0000-0000-000000000000",
          createdDate: new Date("2019-08-08T01:18:06.167Z"),
          modifiedBy: 0,
          modifiedDate: new Date("2019-08-08T01:18:06.167Z"),
          deactivatedBy: 0,
          dateDeactivated: new Date("2019-08-08T01:18:06.167Z"),
          guid: "00000000-0000-0000-0000-000000000000",
          activityId: "00000000-0000-0000-0000-000000000000",
          tenantId: "00000000-0000-0000-0000-000000000000",
          activity: {
            activityName: "string",
            dependentActivityId: "00000000-0000-0000-0000-000000000000",
            activityCategoryId: "00000000-0000-0000-0000-000000000000",
            startDate: new Date("2019-08-08T01:18:06.167Z"),
            endDate: new Date("2019-08-08T01:18:06.167Z"),
            scheduleType: 0,
            activityStatusId: "00000000-0000-0000-0000-000000000000",
            activityStatusName: "string",
            createdBy: "00000000-0000-0000-0000-000000000000",
            createdDate: new Date("2019-08-08T01:18:06.167Z"),
            modifiedBy: "00000000-0000-0000-0000-000000000000",
            modifiedDate: new Date("2019-08-08T01:18:06.167Z"),
            deactivatedBy: "00000000-0000-0000-0000-000000000000",
            dateDeactivated: new Date("2019-08-08T01:18:06.167Z"),
            guid: "00000000-0000-0000-0000-000000000000",
            projectId: "00000000-0000-0000-0000-000000000000",
            tenantId: "00000000-0000-0000-0000-000000000000",
            forms: [
              {
                id: "00000000-0000-0000-0000-000000000000",
                formTitle: "string",
                status: "string",
                roles: ["00000000-0000-0000-0000-000000000000"]
              }
            ],
            entityTypes: ["00000000-0000-0000-0000-000000000000"],
            activityRoles: ["00000000-0000-0000-0000-000000000000"],
            activityRoleNames: ["string"],
            isDefaultActivity: 0,
            isActivityRequireAnEntity: true,
            repeatationCount: 0,
            repeatationOffset: 0
          },
          formDataEntryVariable: [
            {
              id: 0,
              variableId: 0,
              selectedValues: "string",
              selectedValuesInt: 0,
              selectedValuesFloat: 0,
              formDataEntryId: 0,
              createdBy: 0,
              createdDate: new Date("2019-08-08T01:18:06.167Z"),
              modifiedBy: 0,
              modifiedDate: new Date("2019-08-08T01:18:06.167Z"),
              deactivatedBy: 0,
              dateDeactivated: new Date("2019-08-08T01:18:06.167Z"),
              guid: "00000000-0000-0000-0000-000000000000",
              variableName: "string",
              formId: 0,
              parentId: 0,
              activityId: 0,
              formGuid: "00000000-0000-0000-0000-000000000000",
              activityGuid: "00000000-0000-0000-0000-000000000000",
              formDataEntryStatus: 0,
              formTitle: "string"
            }
          ],
          formId: "00000000-0000-0000-0000-000000000000",
          participantId: "string",
          formTitle: "string",
          thisUserId: 0,
          parentEntityNumber: 0,
          projectDeployStatus: 0,
          projectDeployedId: "string",
          projectDeployedVersion: "string",
          summaryPageActivityObjId: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Edit entities endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new SearchApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .searchPut(
        "00000000-0000-0000-0000-000000000000",
        {
          id: 0,
          projectId: "00000000-0000-0000-0000-000000000000",
          entityId: "00000000-0000-0000-0000-000000000000",
          subjectId: 0,
          status: 0,
          createdBy: "00000000-0000-0000-0000-000000000000",
          createdDate: new Date("2019-08-08T01:18:06.167Z"),
          modifiedBy: 0,
          modifiedDate: new Date("2019-08-08T01:18:06.167Z"),
          deactivatedBy: 0,
          dateDeactivated: new Date("2019-08-08T01:18:06.167Z"),
          guid: "00000000-0000-0000-0000-000000000000",
          activityId: "00000000-0000-0000-0000-000000000000",
          tenantId: "00000000-0000-0000-0000-000000000000",
          activity: {
            activityName: "string",
            dependentActivityId: "00000000-0000-0000-0000-000000000000",
            activityCategoryId: "00000000-0000-0000-0000-000000000000",
            startDate: new Date("2019-08-08T01:18:06.167Z"),
            endDate: new Date("2019-08-08T01:18:06.167Z"),
            scheduleType: 0,
            activityStatusId: "00000000-0000-0000-0000-000000000000",
            activityStatusName: "string",
            createdBy: "00000000-0000-0000-0000-000000000000",
            createdDate: new Date("2019-08-08T01:18:06.167Z"),
            modifiedBy: "00000000-0000-0000-0000-000000000000",
            modifiedDate: new Date("2019-08-08T01:18:06.167Z"),
            deactivatedBy: "00000000-0000-0000-0000-000000000000",
            dateDeactivated: new Date("2019-08-08T01:18:06.167Z"),
            guid: "00000000-0000-0000-0000-000000000000",
            projectId: "00000000-0000-0000-0000-000000000000",
            tenantId: "00000000-0000-0000-0000-000000000000",
            forms: [
              {
                id: "00000000-0000-0000-0000-000000000000",
                formTitle: "string",
                status: "string",
                roles: ["00000000-0000-0000-0000-000000000000"]
              }
            ],
            entityTypes: ["00000000-0000-0000-0000-000000000000"],
            activityRoles: ["00000000-0000-0000-0000-000000000000"],
            activityRoleNames: ["string"],
            isDefaultActivity: 0,
            isActivityRequireAnEntity: true,
            repeatationCount: 0,
            repeatationOffset: 0
          },
          formDataEntryVariable: [
            {
              id: 0,
              variableId: 0,
              selectedValues: "string",
              selectedValuesInt: 0,
              selectedValuesFloat: 0,
              formDataEntryId: 0,
              createdBy: 0,
              createdDate: new Date("2019-08-08T01:18:06.167Z"),
              modifiedBy: 0,
              modifiedDate: new Date("2019-08-08T01:18:06.167Z"),
              deactivatedBy: 0,
              dateDeactivated: new Date("2019-08-08T01:18:06.167Z"),
              guid: "00000000-0000-0000-0000-000000000000",
              variableName: "string",
              formId: 0,
              parentId: 0,
              activityId: 0,
              formGuid: "00000000-0000-0000-0000-000000000000",
              activityGuid: "00000000-0000-0000-0000-000000000000",
              formDataEntryStatus: 0,
              formTitle: "string"
            }
          ],
          formId: "00000000-0000-0000-0000-000000000000",
          participantId: "string",
          formTitle: "string",
          thisUserId: 0,
          parentEntityNumber: 0,
          projectDeployStatus: 0,
          projectDeployedId: "string",
          projectDeployedVersion: "string",
          summaryPageActivityObjId: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
