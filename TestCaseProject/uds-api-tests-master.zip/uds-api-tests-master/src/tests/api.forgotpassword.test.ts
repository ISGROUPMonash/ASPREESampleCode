import { ForgotPasswordApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

/*test("[POST] ForgotPassword/GetUserByUsername endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ForgotPasswordApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .forgotPasswordGetUserByUsername(
        {
          username: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] ForgotPassword/GetUserByUsername endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ForgotPasswordApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .forgotPasswordGetUserByUsername(
        {
          username: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});*/

test("[POST] ForgotPassword endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ForgotPasswordApi();
  expect.assertions(0);
  return repeatFlakeyTest(() =>
    api
          .forgotPasswordPost(
        {
          toEMail: "string",
          questionGuid: "00000000-0000-0000-0000-000000000000",
          answer: "string"
        }
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

// todo: Does this endpoint really need authentication??
// todo: How does this API know which password to reset? (email addresses are not unique)
test("[POST] ForgotPassword endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ForgotPasswordApi();
  expect.assertions(0);
  return repeatFlakeyTest(() =>
    api
      .forgotPasswordPost(
        {
          toEMail: "string",
          questionGuid: "00000000-0000-0000-0000-000000000000",
          answer: "string"
        }
      )
      .catch(e => checkHTTPErrorCode(e, 200))
  );
});

test("[POST] ForgotPassword endpoint should not need authentication", () => {
  const api = new ForgotPasswordApi();
  return repeatFlakeyTest(() =>
    api.forgotPasswordPost(
      {
        toEMail: "string",
        questionGuid: "00000000-0000-0000-0000-000000000000",
        answer: "string"
      }
    )
  );
});
