import { ActivityCategoryApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[GET] ActivityCategory endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ActivityCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api.activityCategoryGetAll("").catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] ActivityCategory endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ActivityCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityCategoryGetAll("bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] ActivityCategory endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ActivityCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityCategoryPost({ category: "string" }, "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] ActivityCategory endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ActivityCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityCategoryPost({ category: "string" }, "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] ActivityCategory endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ActivityCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityCategoryDelete("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] ActivityCategory endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ActivityCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityCategoryDelete(
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] ActivityCategory/{guid} endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ActivityCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityCategoryGet("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] ActivityCategory/{guid} endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ActivityCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityCategoryGet(
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] ActivityCategory/{guid} endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ActivityCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityCategoryPut(
        "00000000-0000-0000-0000-000000000000",
        { category: "string" },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] ActivityCategory/{guid} endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ActivityCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityCategoryPut(
        "00000000-0000-0000-0000-000000000000",
        { category: "string" },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
