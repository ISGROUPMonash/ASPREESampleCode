import { FormCategoryApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[GET] Get all form categories endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new FormCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api.formCategoryGetAll("").catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Get all form categories endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new FormCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formCategoryGetAll("bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Form category endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new FormCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formCategoryPost(
        {
          category: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Form category endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new FormCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formCategoryPost(
        {
          category: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] Form category endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new FormCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formCategoryDelete("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] Form category endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new FormCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formCategoryDelete(
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Form category by guid endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new FormCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formCategoryGet("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Form category bu guid endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new FormCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formCategoryGet(
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Form category endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new FormCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formCategoryGet("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Form category endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new FormCategoryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formCategoryGet(
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
