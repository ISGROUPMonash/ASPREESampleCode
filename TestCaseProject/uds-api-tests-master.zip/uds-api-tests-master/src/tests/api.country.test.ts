import { CountryApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[GET] Country endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new CountryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api.countryGetAll("").catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Country endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new CountryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .countryGetAll("bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Country endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new CountryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .countryPost(
        {
          name: "string",
          abbr: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Country endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new CountryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .countryPost(
        {
          name: "string",
          abbr: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] Country/{guid} endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new CountryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .countryDelete("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] Country/{guid} endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new CountryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .countryDelete("00000000-0000-0000-0000-000000000000", "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Country/{guid} endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new CountryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .countryGet("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Country/{guid} endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new CountryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .countryGet("00000000-0000-0000-0000-000000000000", "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Country/{guid} endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new CountryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .countryPut(
        "00000000-0000-0000-0000-000000000000",
        {
          name: "string",
          abbr: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Country/{guid} endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new CountryApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .countryPut(
        "00000000-0000-0000-0000-000000000000",
        {
          name: "string",
          abbr: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
