import { ReportApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[GET] Data export endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ReportApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reportDataExport(
        "testprojectname",
        "",
        "testactivityname",
        "testformname",
        123,
        123
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Data export endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ReportApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .reportDataExport(
        "testprojectname",
        "bad auth header",
        "testactivityname",
        "testformname",
        123,
        123
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
