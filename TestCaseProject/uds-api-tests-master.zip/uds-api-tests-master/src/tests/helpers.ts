interface Retry {
  retry: boolean;
  error?: any;
}

/**
 * Waits for the specified duration
 * @param duration time in ms
 */
function sleep(duration: number) {
  return new Promise(resolve => setTimeout(resolve, duration));
}

/**
 * Tests for the HTTP status code of the API error response
 * @param error the error object thrown by the API request
 * @param code the HTTP error code
 */
async function checkHTTPErrorCode(error: any, code: number): Promise<Retry> {
  // Check whether the error was thrown as part of the HTTP response
  if (error.hasOwnProperty("response")) {
    expect(error.response.statusCode).toBe(code);

  // Check whether the error was thrown as a result of a node.js connection error
  } else if (error.hasOwnProperty("errno") && error.errno === "ECONNRESET") {
    // Return a signal to retry the request
    return {
      retry: true,
      error: error
    };

  // If the cause of the error is unknown, throw a generic error
  } else {
    throw new Error(error);
  }
}

/**
 * A wrapper function that retries a test until it passes or a hard failure
 * is encountered. A hard failure is when an "expect" fails, and a soft failure
 * includes network connectivity issues.
 * @param fn the function containing the test
 * @param sleepDuration the time to wait between retries
 */
async function repeatFlakeyTest(
  fn: () => Promise<Retry | any>,
  sleepDuration: number = 2000
) {

  let retry = true;
  let retryCount = 0;

  // Retries the test until "retry" is set to false
  while (retry) {
    const result = await fn();
    retry = (result as Retry) ? result.retry : false;
    if (retry) {
      retryCount++;
      console.error("Connection error, retrying. (retry #"+retryCount+", sleeping for " + sleepDuration + " ms)");
      console.error(result.error);
      await sleep(sleepDuration);
    }
  }
}

export { checkHTTPErrorCode, repeatFlakeyTest };
