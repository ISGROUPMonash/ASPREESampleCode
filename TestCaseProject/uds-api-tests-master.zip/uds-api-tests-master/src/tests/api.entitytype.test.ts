import { EntityTypeApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[GET] EntityType endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new EntityTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api.entityTypeGetAll("").catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] EntityType endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new EntityTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .entityTypeGetAll("bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] EntityType endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new EntityTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .entityTypePost(
        {
          name: "New Example EntityType"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] EntityType endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new EntityTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .entityTypePost(
        {
          name: "New Example EntityType"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] EntityType/{guid} endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new EntityTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .entityTypeDelete("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] EntityType/{guid} endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new EntityTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .entityTypeDelete(
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] EntityType/{guid} endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new EntityTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .entityTypeGet("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] EntityType/{guid} endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new EntityTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .entityTypeGet("00000000-0000-0000-0000-000000000000", "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] EntityType/{guid} endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new EntityTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .entityTypePut(
        "00000000-0000-0000-0000-000000000000",
        {
          name: "Example EntityType"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] EntityType/{guid} endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new EntityTypeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .entityTypePut(
        "00000000-0000-0000-0000-000000000000",
        {
          name: "Example EntityType"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
