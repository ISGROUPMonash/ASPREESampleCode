import { PrivilegeApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[GET] Privilege endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new PrivilegeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api.privilegeGetAll("").catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Privilege endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new PrivilegeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .privilegeGetAll("bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
