import { ActivityApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[GET] ProjectBuilderActivities endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ActivityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityProjectBuilderActivities(
        "dc7356c7-11d8-4499-8daf-4e53b185a340",
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] ProjectBuilderActivities endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ActivityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityProjectBuilderActivities(
        "dc7356c7-11d8-4499-8daf-4e53b185a340",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] AddSummaryPageActivity endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ActivityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityAddSummaryPageActivity(
        {
          id: 0,
          activityId: "00000000-0000-0000-0000-000000000000",
          activityCompletedByUser: "00000000-0000-0000-0000-000000000000",
          activityDate: new Date("2019-07-16T05:00:16.411Z"),
          isActivityAdded: true,
          projectId: "00000000-0000-0000-0000-000000000000",
          createdBy: "00000000-0000-0000-0000-000000000000",
          createdDate: new Date("2019-07-16T05:00:16.411Z"),
          modifiedBy: "00000000-0000-0000-0000-000000000000",
          modifiedDate: new Date("2019-07-16T05:00:16.411Z"),
          deactivatedBy: "00000000-0000-0000-0000-000000000000",
          dateDeactivated: new Date("2019-07-16T05:00:16.411Z"),
          guid: "00000000-0000-0000-0000-000000000000",
          personEntityId: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] AddSummaryPageActivity endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ActivityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityAddSummaryPageActivity(
        {
          id: 0,
          activityId: "00000000-0000-0000-0000-000000000000",
          activityCompletedByUser: "00000000-0000-0000-0000-000000000000",
          activityDate: new Date("2019-07-16T05:00:16.411Z"),
          isActivityAdded: true,
          projectId: "00000000-0000-0000-0000-000000000000",
          createdBy: "00000000-0000-0000-0000-000000000000",
          createdDate: new Date("2019-07-16T05:00:16.411Z"),
          modifiedBy: "00000000-0000-0000-0000-000000000000",
          modifiedDate: new Date("2019-07-16T05:00:16.411Z"),
          deactivatedBy: "00000000-0000-0000-0000-000000000000",
          dateDeactivated: new Date("2019-07-16T05:00:16.411Z"),
          guid: "00000000-0000-0000-0000-000000000000",
          personEntityId: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] GetAllSummaryPageActivity/{entId}/{projectId} endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ActivityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityGetAllSummaryPageActivity(
        "00000000-0000-0000-0000-000000000000",
        "00000000-0000-0000-0000-000000000000",
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] GetAllSummaryPageActivity/{entId}/{projectId} endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ActivityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityGetAllSummaryPageActivity(
        "00000000-0000-0000-0000-000000000000",
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] EditSummaryPageActivity endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ActivityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityEditSummaryPageActivity(
        {
          id: 0,
          activityId: "00000000-0000-0000-0000-000000000000",
          activityCompletedByUser: "00000000-0000-0000-0000-000000000000",
          activityDate: new Date("2019-07-16T05:00:16.444Z"),
          isActivityAdded: true,
          projectId: "00000000-0000-0000-0000-000000000000",
          createdBy: "00000000-0000-0000-0000-000000000000",
          createdDate: new Date("2019-07-16T05:00:16.444Z"),
          modifiedBy: "00000000-0000-0000-0000-000000000000",
          modifiedDate: new Date("2019-07-16T05:00:16.444Z"),
          deactivatedBy: "00000000-0000-0000-0000-000000000000",
          dateDeactivated: new Date("2019-07-16T05:00:16.444Z"),
          guid: "00000000-0000-0000-0000-000000000000",
          personEntityId: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] EditSummaryPageActivity endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ActivityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityEditSummaryPageActivity(
        {
          id: 0,
          activityId: "00000000-0000-0000-0000-000000000000",
          activityCompletedByUser: "00000000-0000-0000-0000-000000000000",
          activityDate: new Date("2019-07-16T05:00:16.444Z"),
          isActivityAdded: true,
          projectId: "00000000-0000-0000-0000-000000000000",
          createdBy: "00000000-0000-0000-0000-000000000000",
          createdDate: new Date("2019-07-16T05:00:16.444Z"),
          modifiedBy: "00000000-0000-0000-0000-000000000000",
          modifiedDate: new Date("2019-07-16T05:00:16.444Z"),
          deactivatedBy: "00000000-0000-0000-0000-000000000000",
          dateDeactivated: new Date("2019-07-16T05:00:16.444Z"),
          guid: "00000000-0000-0000-0000-000000000000",
          personEntityId: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] DeleteSummaryPageActivity/{id} endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ActivityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityDeleteSummaryPageActivity(123, "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] DeleteSummaryPageActivity/{id} endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ActivityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityDeleteSummaryPageActivity(123, "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Activity endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ActivityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api.activityGetAll("").catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Activity endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ActivityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityGetAll("bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Activity endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ActivityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityPost(
        {
          activityName: "string",
          repeatationType: 0,
          repeatationCount: 0,
          repeatationOffset: 0,
          dependentActivityId: "00000000-0000-0000-0000-000000000000",
          activityCategoryId: "00000000-0000-0000-0000-000000000000",
          startDate: new Date("2019-07-16T05:00:16.489Z"),
          endDate: new Date("2019-07-16T05:00:16.489Z"),
          scheduleType: 0,
          activityStatusId: "00000000-0000-0000-0000-000000000000",
          tenantId: "00000000-0000-0000-0000-000000000000",
          forms: [
            {
              id: "00000000-0000-0000-0000-000000000000",
              formTitle: "string",
              status: "string",
              roles: ["00000000-0000-0000-0000-000000000000"]
            }
          ],
          entityTypes: ["00000000-0000-0000-0000-000000000000"],
          activityRoles: ["00000000-0000-0000-0000-000000000000"],
          projectId: "00000000-0000-0000-0000-000000000000",
          isActivityRequireAnEntity: true
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Activity endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ActivityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityPost(
        {
          activityName: "string",
          repeatationType: 0,
          repeatationCount: 0,
          repeatationOffset: 0,
          dependentActivityId: "00000000-0000-0000-0000-000000000000",
          activityCategoryId: "00000000-0000-0000-0000-000000000000",
          startDate: new Date("2019-07-16T05:00:16.489Z"),
          endDate: new Date("2019-07-16T05:00:16.489Z"),
          scheduleType: 0,
          activityStatusId: "00000000-0000-0000-0000-000000000000",
          tenantId: "00000000-0000-0000-0000-000000000000",
          forms: [
            {
              id: "00000000-0000-0000-0000-000000000000",
              formTitle: "string",
              status: "string",
              roles: ["00000000-0000-0000-0000-000000000000"]
            }
          ],
          entityTypes: ["00000000-0000-0000-0000-000000000000"],
          activityRoles: ["00000000-0000-0000-0000-000000000000"],
          projectId: "00000000-0000-0000-0000-000000000000",
          isActivityRequireAnEntity: true
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] Activity/{guid} endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ActivityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityDelete("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] Activity/{guid} endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ActivityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityDelete("00000000-0000-0000-0000-000000000000", "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Activity/{guid} endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ActivityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityGet("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Activity/{guid} endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ActivityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityGet("00000000-0000-0000-0000-000000000000", "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Activity/{guid} endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ActivityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityPut(
        "00000000-0000-0000-0000-000000000000",
        {
          activityName: "string",
          repeatationType: 0,
          repeatationCount: 0,
          repeatationOffset: 0,
          dependentActivityId: "00000000-0000-0000-0000-000000000000",
          activityCategoryId: "00000000-0000-0000-0000-000000000000",
          startDate: new Date("2019-07-16T05:00:16.489Z"),
          endDate: new Date("2019-07-16T05:00:16.489Z"),
          scheduleType: 0,
          activityStatusId: "00000000-0000-0000-0000-000000000000",
          tenantId: "00000000-0000-0000-0000-000000000000",
          forms: [
            {
              id: "00000000-0000-0000-0000-000000000000",
              formTitle: "string",
              status: "string",
              roles: ["00000000-0000-0000-0000-000000000000"]
            }
          ],
          entityTypes: ["00000000-0000-0000-0000-000000000000"],
          activityRoles: ["00000000-0000-0000-0000-000000000000"],
          projectId: "00000000-0000-0000-0000-000000000000",
          isActivityRequireAnEntity: true
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Activity/{guid} endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ActivityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .activityPut(
        "00000000-0000-0000-0000-000000000000",
        {
          activityName: "string",
          repeatationType: 0,
          repeatationCount: 0,
          repeatationOffset: 0,
          dependentActivityId: "00000000-0000-0000-0000-000000000000",
          activityCategoryId: "00000000-0000-0000-0000-000000000000",
          startDate: new Date("2019-07-16T05:00:16.489Z"),
          endDate: new Date("2019-07-16T05:00:16.489Z"),
          scheduleType: 0,
          activityStatusId: "00000000-0000-0000-0000-000000000000",
          tenantId: "00000000-0000-0000-0000-000000000000",
          forms: [
            {
              id: "00000000-0000-0000-0000-000000000000",
              formTitle: "string",
              status: "string",
              roles: ["00000000-0000-0000-0000-000000000000"]
            }
          ],
          entityTypes: ["00000000-0000-0000-0000-000000000000"],
          activityRoles: ["00000000-0000-0000-0000-000000000000"],
          projectId: "00000000-0000-0000-0000-000000000000",
          isActivityRequireAnEntity: true
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
