import { ProjectDeployApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[POST] Deploy project endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ProjectDeployApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .projectDeployDeployProject("testprojectID", ["testactivitieslist"], "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Deploy project endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ProjectDeployApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .projectDeployDeployProject(
        "testprojectID",
        ["testactivitieslist"],
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Project mongo endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ProjectDeployApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .projectDeployGetProjectMongo("testprojectID", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Project mongo endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ProjectDeployApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .projectDeployGetProjectMongo("testprojectID", "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] All deployed project endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ProjectDeployApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .projectDeployGetAllDeployedProject("")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] All deployed project endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ProjectDeployApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .projectDeployGetAllDeployedProject("bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Push test project endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ProjectDeployApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .projectDeployPushTestProject("testprojectID", ["testactivitieslist"], "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Push test project endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ProjectDeployApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .projectDeployPushTestProject(
        "testprojectID",
        ["testactivitieslist"],
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Check entity linked project endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new ProjectDeployApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .projectDeployCheckEntityLinkedProject("testprojectID", 123, "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Check entity linked project endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new ProjectDeployApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .projectDeployCheckEntityLinkedProject(
        "testprojectID",
        123,
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
