import { SchedulingApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[GET] Scheduling by activity ID endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new SchedulingApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .schedulingGetSchedulingByActivityId(
        "00000000-0000-0000-0000-000000000000",
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Scheduling by activity ID endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new SchedulingApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .schedulingGetSchedulingByActivityId(
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] All scheduled activity by project ID endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new SchedulingApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .schedulingGetAllScheduledActivityByProjectId(
        "00000000-0000-0000-0000-000000000000",
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] All scheduled activity by project ID endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new SchedulingApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .schedulingGetAllScheduledActivityByProjectId(
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Inactivate Activity fails with invalid authentication if Authorization header is blank", () => {
  const api = new SchedulingApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .schedulingInactivateActivity("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Inactivate Activity fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new SchedulingApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .schedulingInactivateActivity(
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Scheduling fails with invalid authentication if Authorization header is blank", () => {
  const api = new SchedulingApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .schedulingGet("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Scheduling fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new SchedulingApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .schedulingGet("00000000-0000-0000-0000-000000000000", "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Scheduling fails with invalid authentication if Authorization header is blank", () => {
  const api = new SchedulingApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .schedulingPut(
        "00000000-0000-0000-0000-000000000000",
        {
          activityId: "00000000-0000-0000-0000-000000000000",
          scheduledToBeCompleted: 0,
          activityAvailableForCreation: 0,
          rolesToCreateActivity: ["00000000-0000-0000-0000-000000000000"],
          roleToCreateActivityRegardlessScheduled: [
            "00000000-0000-0000-0000-000000000000"
          ],
          otherActivity: "00000000-0000-0000-0000-000000000000",
          offsetCount: 0,
          offsetType: 0,
          specifiedActivity: "00000000-0000-0000-0000-000000000000",
          creationWindowOpens: 0,
          creationWindowClose: 0,
          canCreatedMultipleTime: true
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Scheduling fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new SchedulingApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .schedulingPut(
        "00000000-0000-0000-0000-000000000000",
        {
          activityId: "00000000-0000-0000-0000-000000000000",
          scheduledToBeCompleted: 0,
          activityAvailableForCreation: 0,
          rolesToCreateActivity: ["00000000-0000-0000-0000-000000000000"],
          roleToCreateActivityRegardlessScheduled: [
            "00000000-0000-0000-0000-000000000000"
          ],
          otherActivity: "00000000-0000-0000-0000-000000000000",
          offsetCount: 0,
          offsetType: 0,
          specifiedActivity: "00000000-0000-0000-0000-000000000000",
          creationWindowOpens: 0,
          creationWindowClose: 0,
          canCreatedMultipleTime: true
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Scheduling fails with invalid authentication if Authorization header is blank", () => {
  const api = new SchedulingApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .schedulingPost(
        {
          activityId: "00000000-0000-0000-0000-000000000000",
          scheduledToBeCompleted: 0,
          activityAvailableForCreation: 0,
          rolesToCreateActivity: ["00000000-0000-0000-0000-000000000000"],
          roleToCreateActivityRegardlessScheduled: [
            "00000000-0000-0000-0000-000000000000"
          ],
          otherActivity: "00000000-0000-0000-0000-000000000000",
          offsetCount: 0,
          offsetType: 0,
          specifiedActivity: "00000000-0000-0000-0000-000000000000",
          creationWindowOpens: 0,
          creationWindowClose: 0,
          projectId: "00000000-0000-0000-0000-000000000000",
          canCreatedMultipleTime: true
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Scheduling fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new SchedulingApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .schedulingPost(
        {
          activityId: "00000000-0000-0000-0000-000000000000",
          scheduledToBeCompleted: 0,
          activityAvailableForCreation: 0,
          rolesToCreateActivity: ["00000000-0000-0000-0000-000000000000"],
          roleToCreateActivityRegardlessScheduled: [
            "00000000-0000-0000-0000-000000000000"
          ],
          otherActivity: "00000000-0000-0000-0000-000000000000",
          offsetCount: 0,
          offsetType: 0,
          specifiedActivity: "00000000-0000-0000-0000-000000000000",
          creationWindowOpens: 0,
          creationWindowClose: 0,
          projectId: "00000000-0000-0000-0000-000000000000",
          canCreatedMultipleTime: true
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
