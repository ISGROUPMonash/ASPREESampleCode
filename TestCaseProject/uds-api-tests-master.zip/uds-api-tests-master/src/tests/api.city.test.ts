import { CityApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[GET] City endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new CityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api.cityGetAll("").catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] City endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new CityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api.cityGetAll("bad auth header").catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] City endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new CityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .cityPost(
        {
          name: "string",
          stateId: "00000000-0000-0000-0000-000000000000",
          abbr: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] City endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new CityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .cityPost(
        {
          name: "string",
          stateId: "00000000-0000-0000-0000-000000000000",
          abbr: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] City/{guid} endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new CityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .cityDelete("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] City/{guid} endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new CityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .cityDelete("00000000-0000-0000-0000-000000000000", "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] City/{guid} endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new CityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .cityGet("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] City/{guid} endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new CityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .cityGet("00000000-0000-0000-0000-000000000000", "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] City/{guid} endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new CityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .cityPut(
        "00000000-0000-0000-0000-000000000000",
        {
          name: "string",
          stateId: "00000000-0000-0000-0000-000000000000",
          abbr: "string"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] City/{guid} endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new CityApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .cityPut(
        "00000000-0000-0000-0000-000000000000",
        {
          name: "string",
          stateId: "00000000-0000-0000-0000-000000000000",
          abbr: "string"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
