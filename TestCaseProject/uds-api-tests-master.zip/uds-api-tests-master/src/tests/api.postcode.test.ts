import { PostCodeApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[GET] All postcode endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new PostCodeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api.postCodeGetAll("").catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] All postcode endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new PostCodeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .postCodeGetAll("bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Postcode endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new PostCodeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .postCodePost(
        {
          postalCode: "string",
          suburbId: "00000000-0000-0000-0000-000000000000",
          cityId: "00000000-0000-0000-0000-000000000000",
          stateId: "00000000-0000-0000-0000-000000000000"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Postcode endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new PostCodeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .postCodePost(
        {
          postalCode: "string",
          suburbId: "00000000-0000-0000-0000-000000000000",
          cityId: "00000000-0000-0000-0000-000000000000",
          stateId: "00000000-0000-0000-0000-000000000000"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] Postcode endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new PostCodeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .postCodeDelete("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] Postcode endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new PostCodeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .postCodeDelete("00000000-0000-0000-0000-000000000000", "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Postcode endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new PostCodeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .postCodeGet("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Postcode endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new PostCodeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .postCodeGet("00000000-0000-0000-0000-000000000000", "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Postcode endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new PostCodeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .postCodePut(
        "00000000-0000-0000-0000-000000000000",
        {
          postalCode: "string",
          suburbId: "00000000-0000-0000-0000-000000000000",
          cityId: "00000000-0000-0000-0000-000000000000",
          stateId: "00000000-0000-0000-0000-000000000000"
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] Postcode endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new PostCodeApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .postCodePut(
        "00000000-0000-0000-0000-000000000000",
        {
          postalCode: "string",
          suburbId: "00000000-0000-0000-0000-000000000000",
          cityId: "00000000-0000-0000-0000-000000000000",
          stateId: "00000000-0000-0000-0000-000000000000"
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
