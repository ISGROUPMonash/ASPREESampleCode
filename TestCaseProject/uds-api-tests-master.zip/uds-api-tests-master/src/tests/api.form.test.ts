import { FormApi } from "../api/api";
import { checkHTTPErrorCode, repeatFlakeyTest } from "./helpers";

test("[GET] Project builder forms endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new FormApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formProjectBuilderForms("dc7356c7-11d8-4499-8daf-4e53b185a340", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Project builder forms endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new FormApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formProjectBuilderForms(
        "dc7356c7-11d8-4499-8daf-4e53b185a340",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Project default forms endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new FormApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formGetProjectDefaultForms("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Project default forms endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new FormApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formGetProjectDefaultForms(
        "00000000-0000-0000-0000-000000000000",
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Activity form by searched entity endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new FormApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formGetActivityFormBySearchedEntity(
        123,
        "00000000-0000-0000-0000-000000000000",
        "00000000-0000-0000-0000-000000000000",
        123,
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Activity form by searched entity endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new FormApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formGetActivityFormBySearchedEntity(
        123,
        "00000000-0000-0000-0000-000000000000",
        "00000000-0000-0000-0000-000000000000",
        123,
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] All forms endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new FormApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api.formGetAll("").catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] All forms endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new FormApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api.formGetAll("bad auth header").catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Form endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new FormApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api.formGet("", "").catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Form endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new FormApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api.formGet("", "bad auth header").catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Form endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new FormApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formPost(
        {
          formTitle: "string",
          isPublished: true,
          approvedBy: 0,
          approvedDate: new Date("2019-08-08T01:18:05.753Z"),
          isTemplate: true,
          formCategoryId: "00000000-0000-0000-0000-000000000000",
          projectId: "00000000-0000-0000-0000-000000000000",
          formState: 0,
          formStatusId: "00000000-0000-0000-0000-000000000000",
          variables: [
            {
              variableId: "00000000-0000-0000-0000-000000000000",
              variableName: "string",
              isRequired: true,
              helpText: "string",
              minRange: 0,
              maxRange: 0,
              regEx: 0,
              validationRuleType: 0,
              dependentVariableId: "00000000-0000-0000-0000-000000000000",
              responseOption: "string",
              validationMessage: "string",
              formVariableRoles: ["00000000-0000-0000-0000-000000000000"],
              formVariableIsApprovedStatus: true,
              variableType: "string",
              variableViewModel: {
                id: 0,
                variableName: "string",
                variableLabel: "string",
                question: "string",
                values: ["string"],
                valueDescription: "string",
                helpText: "string",
                variableTypeId: "00000000-0000-0000-0000-000000000000",
                validationMessage: "string",
                requiredMessage: "string",
                minRange: 0,
                maxRange: 0,
                regEx: "string",
                isSoftRange: true,
                validationRuleId: "00000000-0000-0000-0000-000000000000",
                dependentVariableId: "00000000-0000-0000-0000-000000000000",
                isRequired: true,
                canCollectMultiple: true,
                variableCategoryId: "00000000-0000-0000-0000-000000000000",
                isApproved: true,
                comment: "string",
                createdBy: "00000000-0000-0000-0000-000000000000",
                createdDate: new Date("2019-08-08T01:18:05.753Z"),
                modifiedBy: "00000000-0000-0000-0000-000000000000",
                modifiedDate: new Date("2019-08-08T01:18:05.753Z"),
                deactivatedBy: "00000000-0000-0000-0000-000000000000",
                dateDeactivated: new Date("2019-08-08T01:18:05.753Z"),
                guid: "00000000-0000-0000-0000-000000000000",
                variableRoles: ["00000000-0000-0000-0000-000000000000"],
                tenantId: "00000000-0000-0000-0000-000000000000",
                variableTypeName: "string",
                validationRuleIds: ["00000000-0000-0000-0000-000000000000"],
                validationRuleViewModel: [
                  {
                    ruleType: "string",
                    minRange: 0,
                    maxRange: 0,
                    regExId: "00000000-0000-0000-0000-000000000000",
                    errorMessage: "string",
                    regEx: "string",
                    guid: "00000000-0000-0000-0000-000000000000"
                  }
                ],
                customRegEx: "string",
                variableValidationRuleViewModel: [
                  {
                    id: 0,
                    variableId: 0,
                    validationId: 0,
                    validationMessage: "string",
                    regEx: "string",
                    min: 0,
                    max: 0,
                    limitType: "string",
                    guid: "00000000-0000-0000-0000-000000000000",
                    validationName: "string"
                  }
                ],
                variableValueDescription: ["string"],
                isVariableLogTable: true,
                isDefaultVariable: 0,
                variableSelectedValues: "string",
                formDataEntryGuid: "00000000-0000-0000-0000-000000000000",
                outsideRangeValidation: "string",
                missingValidation: "string",
                lookupEntityType: "00000000-0000-0000-0000-000000000000",
                lookupEntitySubtype: "00000000-0000-0000-0000-000000000000",
                lookupEntityTypeName: "string",
                lookupEntitySubtypeName: "string",
                dateFormat: "string",
                canFutureDate: true,
                userNameVariableGuid: "00000000-0000-0000-0000-000000000000",
                variableUsedInFormsList: [
                  "00000000-0000-0000-0000-000000000000"
                ]
              },
              formVariableRoleViewModel: [
                {
                  formVariableId: 0,
                  roleGuidId: "00000000-0000-0000-0000-000000000000",
                  guid: "00000000-0000-0000-0000-000000000000",
                  canCreate: true,
                  canView: true,
                  canEdit: true,
                  canDelete: true
                }
              ],
              isSearchVisible: true,
              searchPageOrder: 0,
              isDefaultVariableType: 0,
              questionText: "string"
            }
          ],
          entityTypes: ["00000000-0000-0000-0000-000000000000"]
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[POST] Form endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new FormApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formPost(
        {
          formTitle: "string",
          isPublished: true,
          approvedBy: 0,
          approvedDate: new Date("2019-08-08T01:18:05.753Z"),
          isTemplate: true,
          formCategoryId: "00000000-0000-0000-0000-000000000000",
          projectId: "00000000-0000-0000-0000-000000000000",
          formState: 0,
          formStatusId: "00000000-0000-0000-0000-000000000000",
          variables: [
            {
              variableId: "00000000-0000-0000-0000-000000000000",
              variableName: "string",
              isRequired: true,
              helpText: "string",
              minRange: 0,
              maxRange: 0,
              regEx: 0,
              validationRuleType: 0,
              dependentVariableId: "00000000-0000-0000-0000-000000000000",
              responseOption: "string",
              validationMessage: "string",
              formVariableRoles: ["00000000-0000-0000-0000-000000000000"],
              formVariableIsApprovedStatus: true,
              variableType: "string",
              variableViewModel: {
                id: 0,
                variableName: "string",
                variableLabel: "string",
                question: "string",
                values: ["string"],
                valueDescription: "string",
                helpText: "string",
                variableTypeId: "00000000-0000-0000-0000-000000000000",
                validationMessage: "string",
                requiredMessage: "string",
                minRange: 0,
                maxRange: 0,
                regEx: "string",
                isSoftRange: true,
                validationRuleId: "00000000-0000-0000-0000-000000000000",
                dependentVariableId: "00000000-0000-0000-0000-000000000000",
                isRequired: true,
                canCollectMultiple: true,
                variableCategoryId: "00000000-0000-0000-0000-000000000000",
                isApproved: true,
                comment: "string",
                createdBy: "00000000-0000-0000-0000-000000000000",
                createdDate: new Date("2019-08-08T01:18:05.753Z"),
                modifiedBy: "00000000-0000-0000-0000-000000000000",
                modifiedDate: new Date("2019-08-08T01:18:05.753Z"),
                deactivatedBy: "00000000-0000-0000-0000-000000000000",
                dateDeactivated: new Date("2019-08-08T01:18:05.753Z"),
                guid: "00000000-0000-0000-0000-000000000000",
                variableRoles: ["00000000-0000-0000-0000-000000000000"],
                tenantId: "00000000-0000-0000-0000-000000000000",
                variableTypeName: "string",
                validationRuleIds: ["00000000-0000-0000-0000-000000000000"],
                validationRuleViewModel: [
                  {
                    ruleType: "string",
                    minRange: 0,
                    maxRange: 0,
                    regExId: "00000000-0000-0000-0000-000000000000",
                    errorMessage: "string",
                    regEx: "string",
                    guid: "00000000-0000-0000-0000-000000000000"
                  }
                ],
                customRegEx: "string",
                variableValidationRuleViewModel: [
                  {
                    id: 0,
                    variableId: 0,
                    validationId: 0,
                    validationMessage: "string",
                    regEx: "string",
                    min: 0,
                    max: 0,
                    limitType: "string",
                    guid: "00000000-0000-0000-0000-000000000000",
                    validationName: "string"
                  }
                ],
                variableValueDescription: ["string"],
                isVariableLogTable: true,
                isDefaultVariable: 0,
                variableSelectedValues: "string",
                formDataEntryGuid: "00000000-0000-0000-0000-000000000000",
                outsideRangeValidation: "string",
                missingValidation: "string",
                lookupEntityType: "00000000-0000-0000-0000-000000000000",
                lookupEntitySubtype: "00000000-0000-0000-0000-000000000000",
                lookupEntityTypeName: "string",
                lookupEntitySubtypeName: "string",
                dateFormat: "string",
                canFutureDate: true,
                userNameVariableGuid: "00000000-0000-0000-0000-000000000000",
                variableUsedInFormsList: [
                  "00000000-0000-0000-0000-000000000000"
                ]
              },
              formVariableRoleViewModel: [
                {
                  formVariableId: 0,
                  roleGuidId: "00000000-0000-0000-0000-000000000000",
                  guid: "00000000-0000-0000-0000-000000000000",
                  canCreate: true,
                  canView: true,
                  canEdit: true,
                  canDelete: true
                }
              ],
              isSearchVisible: true,
              searchPageOrder: 0,
              isDefaultVariableType: 0,
              questionText: "string"
            }
          ],
          entityTypes: ["00000000-0000-0000-0000-000000000000"]
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] Form endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new FormApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formDelete("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[DELETE] Form endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new FormApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formDelete("00000000-0000-0000-0000-000000000000", "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Form endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new FormApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formGet("00000000-0000-0000-0000-000000000000", "")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[GET] Form endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new FormApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formGet("00000000-0000-0000-0000-000000000000", "bad auth header")
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] endpoint fails with invalid authentication if Authorization header is blank", () => {
  const api = new FormApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formPut(
        "00000000-0000-0000-0000-000000000000",
        {
          id: 0,
          formTitle: "string",
          isPublished: true,
          approvedBy: 0,
          approvedDate: new Date("2019-08-08T01:18:05.780Z"),
          isTemplate: true,
          formCategoryId: "00000000-0000-0000-0000-000000000000",
          projectId: "00000000-0000-0000-0000-000000000000",
          formState: 0,
          formStatusId: "00000000-0000-0000-0000-000000000000",
          guid: "00000000-0000-0000-0000-000000000000",
          variables: [
            {
              variableId: "00000000-0000-0000-0000-000000000000",
              variableName: "string",
              isRequired: true,
              helpText: "string",
              minRange: 0,
              maxRange: 0,
              regEx: 0,
              validationRuleType: 0,
              dependentVariableId: "00000000-0000-0000-0000-000000000000",
              responseOption: "string",
              validationMessage: "string",
              formVariableRoles: ["00000000-0000-0000-0000-000000000000"],
              formVariableIsApprovedStatus: true,
              variableType: "string",
              variableViewModel: {
                id: 0,
                variableName: "string",
                variableLabel: "string",
                question: "string",
                values: ["string"],
                valueDescription: "string",
                helpText: "string",
                variableTypeId: "00000000-0000-0000-0000-000000000000",
                validationMessage: "string",
                requiredMessage: "string",
                minRange: 0,
                maxRange: 0,
                regEx: "string",
                isSoftRange: true,
                validationRuleId: "00000000-0000-0000-0000-000000000000",
                dependentVariableId: "00000000-0000-0000-0000-000000000000",
                isRequired: true,
                canCollectMultiple: true,
                variableCategoryId: "00000000-0000-0000-0000-000000000000",
                isApproved: true,
                comment: "string",
                createdBy: "00000000-0000-0000-0000-000000000000",
                createdDate: new Date("2019-08-08T01:18:05.780Z"),
                modifiedBy: "00000000-0000-0000-0000-000000000000",
                modifiedDate: new Date("2019-08-08T01:18:05.780Z"),
                deactivatedBy: "00000000-0000-0000-0000-000000000000",
                dateDeactivated: new Date("2019-08-08T01:18:05.780Z"),
                guid: "00000000-0000-0000-0000-000000000000",
                variableRoles: ["00000000-0000-0000-0000-000000000000"],
                tenantId: "00000000-0000-0000-0000-000000000000",
                variableTypeName: "string",
                validationRuleIds: ["00000000-0000-0000-0000-000000000000"],
                validationRuleViewModel: [
                  {
                    ruleType: "string",
                    minRange: 0,
                    maxRange: 0,
                    regExId: "00000000-0000-0000-0000-000000000000",
                    errorMessage: "string",
                    regEx: "string",
                    guid: "00000000-0000-0000-0000-000000000000"
                  }
                ],
                customRegEx: "string",
                variableValidationRuleViewModel: [
                  {
                    id: 0,
                    variableId: 0,
                    validationId: 0,
                    validationMessage: "string",
                    regEx: "string",
                    min: 0,
                    max: 0,
                    limitType: "string",
                    guid: "00000000-0000-0000-0000-000000000000",
                    validationName: "string"
                  }
                ],
                variableValueDescription: ["string"],
                isVariableLogTable: true,
                isDefaultVariable: 0,
                variableSelectedValues: "string",
                formDataEntryGuid: "00000000-0000-0000-0000-000000000000",
                outsideRangeValidation: "string",
                missingValidation: "string",
                lookupEntityType: "00000000-0000-0000-0000-000000000000",
                lookupEntitySubtype: "00000000-0000-0000-0000-000000000000",
                lookupEntityTypeName: "string",
                lookupEntitySubtypeName: "string",
                dateFormat: "string",
                canFutureDate: true,
                userNameVariableGuid: "00000000-0000-0000-0000-000000000000",
                variableUsedInFormsList: [
                  "00000000-0000-0000-0000-000000000000"
                ]
              },
              formVariableRoleViewModel: [
                {
                  formVariableId: 0,
                  roleGuidId: "00000000-0000-0000-0000-000000000000",
                  guid: "00000000-0000-0000-0000-000000000000",
                  canCreate: true,
                  canView: true,
                  canEdit: true,
                  canDelete: true
                }
              ],
              isSearchVisible: true,
              searchPageOrder: 0,
              isDefaultVariableType: 0,
              questionText: "string"
            }
          ],
          entityTypes: ["00000000-0000-0000-0000-000000000000"]
        },
        ""
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});

test("[PUT] endpoint fails with invalid authentication if Authorization header is invalid and not blank", () => {
  const api = new FormApi();
  expect.assertions(1);
  return repeatFlakeyTest(() =>
    api
      .formPut(
        "00000000-0000-0000-0000-000000000000",
        {
          id: 0,
          formTitle: "string",
          isPublished: true,
          approvedBy: 0,
          approvedDate: new Date("2019-08-08T01:18:05.780Z"),
          isTemplate: true,
          formCategoryId: "00000000-0000-0000-0000-000000000000",
          projectId: "00000000-0000-0000-0000-000000000000",
          formState: 0,
          formStatusId: "00000000-0000-0000-0000-000000000000",
          guid: "00000000-0000-0000-0000-000000000000",
          variables: [
            {
              variableId: "00000000-0000-0000-0000-000000000000",
              variableName: "string",
              isRequired: true,
              helpText: "string",
              minRange: 0,
              maxRange: 0,
              regEx: 0,
              validationRuleType: 0,
              dependentVariableId: "00000000-0000-0000-0000-000000000000",
              responseOption: "string",
              validationMessage: "string",
              formVariableRoles: ["00000000-0000-0000-0000-000000000000"],
              formVariableIsApprovedStatus: true,
              variableType: "string",
              variableViewModel: {
                id: 0,
                variableName: "string",
                variableLabel: "string",
                question: "string",
                values: ["string"],
                valueDescription: "string",
                helpText: "string",
                variableTypeId: "00000000-0000-0000-0000-000000000000",
                validationMessage: "string",
                requiredMessage: "string",
                minRange: 0,
                maxRange: 0,
                regEx: "string",
                isSoftRange: true,
                validationRuleId: "00000000-0000-0000-0000-000000000000",
                dependentVariableId: "00000000-0000-0000-0000-000000000000",
                isRequired: true,
                canCollectMultiple: true,
                variableCategoryId: "00000000-0000-0000-0000-000000000000",
                isApproved: true,
                comment: "string",
                createdBy: "00000000-0000-0000-0000-000000000000",
                createdDate: new Date("2019-08-08T01:18:05.780Z"),
                modifiedBy: "00000000-0000-0000-0000-000000000000",
                modifiedDate: new Date("2019-08-08T01:18:05.780Z"),
                deactivatedBy: "00000000-0000-0000-0000-000000000000",
                dateDeactivated: new Date("2019-08-08T01:18:05.780Z"),
                guid: "00000000-0000-0000-0000-000000000000",
                variableRoles: ["00000000-0000-0000-0000-000000000000"],
                tenantId: "00000000-0000-0000-0000-000000000000",
                variableTypeName: "string",
                validationRuleIds: ["00000000-0000-0000-0000-000000000000"],
                validationRuleViewModel: [
                  {
                    ruleType: "string",
                    minRange: 0,
                    maxRange: 0,
                    regExId: "00000000-0000-0000-0000-000000000000",
                    errorMessage: "string",
                    regEx: "string",
                    guid: "00000000-0000-0000-0000-000000000000"
                  }
                ],
                customRegEx: "string",
                variableValidationRuleViewModel: [
                  {
                    id: 0,
                    variableId: 0,
                    validationId: 0,
                    validationMessage: "string",
                    regEx: "string",
                    min: 0,
                    max: 0,
                    limitType: "string",
                    guid: "00000000-0000-0000-0000-000000000000",
                    validationName: "string"
                  }
                ],
                variableValueDescription: ["string"],
                isVariableLogTable: true,
                isDefaultVariable: 0,
                variableSelectedValues: "string",
                formDataEntryGuid: "00000000-0000-0000-0000-000000000000",
                outsideRangeValidation: "string",
                missingValidation: "string",
                lookupEntityType: "00000000-0000-0000-0000-000000000000",
                lookupEntitySubtype: "00000000-0000-0000-0000-000000000000",
                lookupEntityTypeName: "string",
                lookupEntitySubtypeName: "string",
                dateFormat: "string",
                canFutureDate: true,
                userNameVariableGuid: "00000000-0000-0000-0000-000000000000",
                variableUsedInFormsList: [
                  "00000000-0000-0000-0000-000000000000"
                ]
              },
              formVariableRoleViewModel: [
                {
                  formVariableId: 0,
                  roleGuidId: "00000000-0000-0000-0000-000000000000",
                  guid: "00000000-0000-0000-0000-000000000000",
                  canCreate: true,
                  canView: true,
                  canEdit: true,
                  canDelete: true
                }
              ],
              isSearchVisible: true,
              searchPageOrder: 0,
              isDefaultVariableType: 0,
              questionText: "string"
            }
          ],
          entityTypes: ["00000000-0000-0000-0000-000000000000"]
        },
        "bad auth header"
      )
      .catch(e => checkHTTPErrorCode(e, 401))
  );
});
