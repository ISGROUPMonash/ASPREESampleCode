# UDS API tests

## Prerequisites
* [node.js](https://nodejs.org/) and [npm](https://www.npmjs.com/get-npm) (npm is installed automatically with node.js)
* [yarn](https://yarnpkg.com/) package manager

## Installation
1. Clone the repository: `git clone https://github.com/jasonrig/uds-api-tests.git`
2. Change into the cloned repository: `cd uds-api-tests`
3. Install the dependencies using yarn: `yarn install`
4. Run the API tests: `yarn test`
5. Read the HTML file produced (`test-report.html`)

## Updating the API
1. Install the [Swagger code generator](https://swagger.io/tools/swagger-codegen/)
2. Change into the api directory: `cd src/api`
3. Run the code generator command: `swagger-codegen generate -i http://uds.cloud.monash.edu:8081/swagger/docs/v1 -l typescript-node -DsupportsES6=true`
